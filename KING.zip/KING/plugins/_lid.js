const handler = async (msg, { conn }) => {
  const chatId = msg.key.remoteJid
  const senderId = msg.key.participant || msg.key.remoteJid

  // رد فعل تلقائي
  await conn.sendMessage(chatId, {
    react: { text: '🛰️', key: msg.key }
  })

  // استخراج رقم المقتبس أو المُرسل
  const context = msg.message?.extendedTextMessage?.contextInfo
  const citado = context?.participant
  const objetivo = citado || senderId

  const esLID = objetivo.endsWith('@lid')
  const tipo = esLID ? 'معرّف مخفي (@lid)' : 'رقم ظاهر (@s.whatsapp.net)'
  const numero = objetivo.replace(/[^0-9]/g, '')

  const mensaje = `
📡 *معلومات المستخدم المكتشَف:*

👤 *المعرّف:* ${objetivo}
📱 *الرقم:* +${numero}
🔐 *نوع الحساب:* ${tipo}
`.trim()

  await conn.sendMessage(chatId, {
    text: mensaje
  }, { quoted: msg })
}

// تغيير اسم الأمر إلى عربي
handler.command = ['معرف'] // ← اكتب ".معرف" في المجموعة
handler.group = true
handler.private = false

export default handler