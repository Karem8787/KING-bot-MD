import fs from 'fs'
import path from 'path'

let handler = async (m, { text }) => {
  if (!text || !text.replace(/[^0-9]/g, '')) {
    return m.reply('يجب أن تشير إلى البوت الذي تريد تعيينه كبوت رئيسي في هذه المجموعة.')
  }

  let number = text.replace(/[^0-9]/g, '')
  let botJid = number + '@s.whatsapp.net'
  let subbotPath = path.join('./JadiBots', number, 'creds.json')

  // التحقق من أن الرقم يعود لبوت فرعي (يوجد له creds.json)
  if (!fs.existsSync(subbotPath)) {
    return m.reply(`الرقم *${number}* لا يطابق أي بوت فرعي صالح (لم يتم العثور على ملف creds.json في مجلد JadiBots).`)
  }

  if (!global.db.data.chats[m.chat]) global.db.data.chats[m.chat] = {}

  global.db.data.chats[m.chat].primaryBot = botJid

  m.reply(`✅ تم تعيين هذا البوت كبوت رئيسي للمجموعة:\n*${botJid}*`)
}

handler.help = ['تعين @بوت']
handler.tags = ['serbot']
handler.command = ['تعين']
handler.admin = true

export default handler