let handler = m => m;

let canalId = ["120363422248474738@newsletter", "120363422248474738@newsletter"];
let canalNombre = ["𝑲𝑰𝑵𝑮 💫", "𝑲𝑰𝑵𝑮 ✨"];

handler.all = async function (m, { conn }) {
  if (m.key.fromMe) return;

  let chat = global.db.data.chats[m.chat];
  if (chat?.isBanned) return;

  let isFromChannel = canalId.includes(m.chat);
  if (isFromChannel) {
    console.log("تم استقبال رسالة من قناة:", m.chat);
  }

  const sendAdReply = async (text) => {
    await conn.sendMessage(m.chat, {
      text,
      contextInfo: {
        externalAdReply: {
          title: "𝑲𝑰𝑵𝑮",
          body: isFromChannel ? `مرسلة من ${canalNombre[canalId.indexOf(m.chat)]}` : "𝑾𝑨𝑯𝑴 𝑩𝑶𝑻",
          thumbnailUrl: "https://whatsapp.com/channel/0029Vb6UFoi05MUe24Jo7r1r",
          sourceUrl: "https://whatsapp.com/channel/0029Vb6UFoi05MUe24Jo7r1r",
          mediaType: 1,
          showAdAttribution: true,
          renderLargerThumbnail: false
        }
      }
    }, { quoted: m });
  };

  // مثال بسيط فقط للتجربة على قناة
  if (/^قناة$/i.test(m.text)) await sendAdReply("*رد تجريبي على القناة أو الشات*");

  return !0;
};

export default handler;