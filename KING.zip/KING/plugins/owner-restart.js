let handler = async (m, { conn, usedPrefix, command }) => {

    try {
        m.reply('「❀ جاري اعاده تشغيل البوت....')
        setTimeout(() => {
            process.exit(0)
        }, 3000) 
    } catch (error) {
        console.log(error)
        conn.reply(m.chat, `${error}`, m)
    }
}

handler.help = ['ريستارت']
handler.tags = ['owner']
handler.command = ['ريستارت'] 
handler.rowner = true

export default handler