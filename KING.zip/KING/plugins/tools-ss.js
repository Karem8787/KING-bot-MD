import fetch from 'node-fetch'

let handler = async (m, { conn, args }) => {
  if (!args[0]) return conn.reply(m.chat, `☁︎ الرجاء إدخال رابط صفحة ويب.`, m)

  try {
    await m.react('⏳')
    conn.reply(m.chat, `> جاري معالجة طلبك...`, m)

    let url = `https://image.thum.io/get/fullpage/${args[0]}`
    let res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
      }
    })

    let contentType = res.headers.get('content-type') || ''
    if (!res.ok || !contentType.startsWith('image/')) {
      throw new Error('لم يتم استلام صورة صالحة.')
    }

    let ss = await res.buffer()

    await m.react('📸')
    await conn.sendFile(m.chat, ss, 'captura.png', `✅ لقطة شاشة من:\n${args[0]}`, m)
    await m.react('✅')

  } catch (err) {
    console.error('[❌ خطأ في لقطة الشاشة]', err)
    await m.react('❌')
    conn.reply(m.chat, `⚠️ لم يتمكن البوت من التقاط صورة للصفحة.\nتأكد أن الرابط صحيح ولا يحتاج لتسجيل دخول.`, m)
  }
}

handler.help = ['شوت <رابط الموقع>']
handler.tags = ['tools']
handler.command = ['شوت']
handler.register = true
export default handler