import { promises as fs } from 'fs'

const charactersFilePath = './database/characters.json'
const haremFilePath = './database/harem.json'

async function loadCharacters() {
    try {
        const data = await fs.readFile(charactersFilePath, 'utf-8')
        return JSON.parse(data)
    } catch (error) {
        throw new Error('❌ لم نتمكن من تحميل معلومات الشخصيات.\n> ● *إذا كنت تعتقد أن هذا خطأ، أرسل /report*')
    }
}

async function saveCharacters(characters) {
    try {
        await fs.writeFile(charactersFilePath, JSON.stringify(characters, null, 2), 'utf-8')
    } catch (error) {
        throw new Error('❌ لم نتمكن من حفظ بيانات الشخصيات.\n> ● *حاول مرة أخرى لاحقًا.*')
    }
}

async function loadHarem() {
    try {
        const data = await fs.readFile(haremFilePath, 'utf-8')
        return JSON.parse(data)
    } catch {
        return []
    }
}

async function saveHarem(harem) {
    try {
        await fs.writeFile(haremFilePath, JSON.stringify(harem, null, 2))
    } catch (error) {
        throw new Error('❌ لم نتمكن من حفظ بيانات الحريم.\n> ● *حاول مرة أخرى لاحقًا.*')
    }
}

let handler = async (m, { conn, args }) => {
    const userId = m.sender

    if (args.length < 2) {
        await conn.sendMessage(m.chat, { 
            text: '⚠️ يجب عليك تحديد اسم الشخصية وذكر المستخدم الذي تريد إعطاءه إياها.\n> ● *مثال ›* /regalar Aika Sano @user', 
            ...global.rcanal 
        }, { quoted: m })
        return
    }

    const characterName = args.slice(0, -1).join(' ').toLowerCase().trim()
    let who = m.mentionedJid[0]

    if (!who) {
        await conn.sendMessage(m.chat, { 
            text: '⚠️ يجب عليك ذكر مستخدم صحيح.\n> ● *مثال ›* /regalar Aika Sano @user', 
            ...global.rcanal 
        }, { quoted: m })
        return
    }

    try {
        const characters = await loadCharacters()
        const character = characters.find(c => c.name.toLowerCase() === characterName && c.user === userId)

        if (!character) {
            await conn.sendMessage(m.chat, { 
                text: `⚠️ الشخصية *${characterName}* ليست مملوكة لك.\n> ● *استخدم /harem لرؤية قائمتك.*`, 
                ...global.rcanal 
            }, { quoted: m })
            return
        }

        character.user = who
        await saveCharacters(characters)

        const harem = await loadHarem()
        const userEntryIndex = harem.findIndex(entry => entry.userId === who)

        if (userEntryIndex !== -1) {
            harem[userEntryIndex].characterId = character.id
            harem[userEntryIndex].lastClaimTime = Date.now()
        } else {
            harem.push({
                userId: who,
                characterId: character.id,
                lastClaimTime: Date.now()
            })
        }

        await saveHarem(harem)

        await conn.sendMessage(m.chat, { 
            text: `🎁 *${character.name}* أصبحت الآن ملكًا لـ @${who.split('@')[0]}!\n> ● *استمتع بشخصيتك الجديدة!*`, 
            mentions: [who],
            ...global.rcanal 
        }, { quoted: m })
    } catch (error) {
        await conn.sendMessage(m.chat, { 
            text: `❌ حدث خطأ أثناء المحاولة.\n> ● *الخطأ ›* ${error.message}`, 
            ...global.rcanal 
        }, { quoted: m })
    }
}

handler.help = ['اعطاء']
handler.tags = ['gacha']
handler.command = ['اعطاء']
handler.group = false
handler.register = true

export default handler