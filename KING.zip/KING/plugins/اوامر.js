import pkg from '@whiskeysockets/baileys'
const { prepareWAMessageMedia } = pkg

const handler = async (m, { conn, usedPrefix }) => {
  let user = global.db.data.users[m.sender]
  let name = await conn.getName(m.sender)
  let totalCommands = Object.values(global.plugins).filter(v => v?.help?.length).length

  let response = `╭──〔 مرحباً بك يا ${name} 〕──⬣
│
├ 🧍‍♂️ *الاسم:* ${name}
├ ✨ *الخبرة:* ${user.exp} XP
├ 💰 *الرصيد:* ${user.bank}$
│
├ 🤖 *اسم البوت:* WAHEM BOT
├ 📚 *عدد الأوامر:* ${totalCommands}
├ 👨‍💻 *المطور:* كينج
│
├ 🧾 *جميع الأوامر:*
`

  // عرض الأوامر تحت بعض بدون تصنيف
  let allCommands = []
  for (let plugin of Object.values(global.plugins)) {
    if (!plugin?.help) continue
    for (let cmd of plugin.help) {
      allCommands.push(`> ${usedPrefix}${cmd}`)
    }
  }

  response += allCommands.join('\n')
  response += `\n╰────────────⬣`

  const imageUrl = 'https://files.catbox.moe/ocescd.jpg'

  await conn.relayMessage(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: '📜 قائمة الأوامر',
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer }))
          },
          body: {
            text: response,
            subtitle: 'WAHEM BOT'
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: 'quick_reply',
                buttonParamsJson: `{\"display_text\":\"🌟 المطور\",\"id\":\"${usedPrefix}مطور\"}`
              },
              {
                name: 'quick_reply',
                buttonParamsJson: `{\"display_text\":\"⭐ تقييم البوت\",\"id\":\"${usedPrefix}تقيم\"}`
              },
              {
                name: 'url',
                buttonParamsJson: `{\"display_text\":\"📢 قناة البوت\",\"url\":\"https://whatsapp.com/channel/0029Vb6UFoi05MUe24Jo7r1r\"}`
              }
            ]
          },
          messageParamsJson: '「 مركز الأوامر 」'
        }
      }
    }
  }, {})
}

handler.help = ['اوامر']
handler.tags = ['main']
handler.command = ['اوامر', 'الاوامر']

export default handler