import db from '../lib/database.js'

let handler = async (m, { conn, usedPrefix }) => {
  let who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender
  if (who == conn.user.jid) return m.react('✖️')
  if (!(who in global.db.data.users)) return m.reply(`❗ المستخدم غير موجود في قاعدة البيانات.`)

  let user = global.db.data.users[who]
  let total = (user.coin || 0) + (user.bank || 0)
  let name = await conn.getName(who)

  const texto = 
`📊 *الملف المالي للمستخدم* 📒

👤 الاسم: *${name}*
💰 الكاش: *${user.coin || 0} ${moneda}*
🏦 البنك: *${user.bank || 0} ${moneda}*
💵 الإجمالي: *${total} ${moneda}*

✍️ استخدم الأمر *${usedPrefix}ايداع* لحفظ أموالك في البنك.`

  await conn.reply(m.chat, texto, m, rcanal)
}

handler.help = ['الرصيد']
handler.tags = ['eco']
handler.command = ['الرصيد']
handler.register = true
handler.group = false 

export default handler