import fs from 'fs'
import path from 'path'

const handler = async (m, { conn }) => {
  const jadiPath = './JadiBots'
  let listaSubs = []

  // ✦ التحقق من وجود مجلد البوتات الفرعية
  if (fs.existsSync(jadiPath)) {
    const carpetas = fs.readdirSync(jadiPath).filter(f => fs.statSync(path.join(jadiPath, f)).isDirectory())

    for (const carpeta of carpetas) {
      const configPath = path.join(jadiPath, carpeta, 'config.json')
      if (fs.existsSync(configPath)) {
        try {
          const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'))
          const nombre = config.name || '❀ بدون اسم مخصص'
          const numero = carpeta
          listaSubs.push({ numero, nombre })
        } catch (e) {
          console.log(`✘ خطأ أثناء قراءة config في البوت الفرعي: ${carpeta}`)
        }
      }
    }
  }

  // ✦ إذا لم يكن هناك بوتات فرعية نشطة
  if (!listaSubs.length) {
    return conn.reply(m.chat, `
❀ *البوتات الفرعية المخصصة* 

➪ ✦ *لا يوجد بوتات فرعية نشطة حالياً*
➪ ❀ استخدم الأمر *.setname* لإنشاء واحد
`.trim(), m)
  }

  // ✦ إذا وُجدت بوتات فرعية
  let msg = `
*البوتات الفرعية النشطة*\n
`

  listaSubs.forEach((s, i) => {
    msg += `➪ ✦ *${i + 1}.* ${s.nombre}\n`
    msg += `   ⤷ ❀ *الرقم:* wa.me/${s.numero}\n\n`
  })

  msg += `➪ ✦ ❀ *الإجمالي:* ${listaSubs.length}\n`
  msg += `╰────────❀────────╯`

  await conn.reply(m.chat, msg.trim(), m)
}

handler.help = ['بوتات']
handler.tags = ['serbot']
handler.command = ['بوتات']

export default handler