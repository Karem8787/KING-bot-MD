import { promises as fs } from 'fs'

const charactersFilePath = './database/characters.json'
const haremFilePath = './database/harem.json'

const cooldowns = {}

async function loadCharacters() {
    try {
        const data = await fs.readFile(charactersFilePath, 'utf-8')
        return JSON.parse(data)
    } catch (error) {
        throw new Error('❀ لم نتمكن من تحميل ملف الشخصيات.')
    }
}

async function saveCharacters(characters) {
    try {
        await fs.writeFile(charactersFilePath, JSON.stringify(characters, null, 2), 'utf-8')
    } catch (error) {
        throw new Error('❀ لم نتمكن من حفظ ملف الشخصيات.')
    }
}

async function loadHarem() {
    try {
        const data = await fs.readFile(haremFilePath, 'utf-8')
        return JSON.parse(data)
    } catch (error) {
        return []
    }
}

async function saveHarem(harem) {
    try {
        await fs.writeFile(haremFilePath, JSON.stringify(harem, null, 2), 'utf-8')
    } catch (error) {
        throw new Error('❀ لم نتمكن من حفظ ملف الحريم.')
    }
}

let handler = async (m, { conn }) => {
    const userId = m.sender
    const now = Date.now()

    if (cooldowns[userId] && now < cooldowns[userId]) {
        const remainingTime = Math.ceil((cooldowns[userId] - now) / 1000)
        const minutes = Math.floor(remainingTime / 60)
        const seconds = remainingTime % 60
        return await conn.reply(m.chat, `《✧》يرجى الانتظار *${minutes} دقيقة و ${seconds} ثانية* قبل استخدام الأمر مرة أخرى.`, m)
    }

    try {
        const characters = await loadCharacters()
        const randomCharacter = characters[Math.floor(Math.random() * characters.length)]
        const randomImage = randomCharacter.img[Math.floor(Math.random() * randomCharacter.img.length)]

        const harem = await loadHarem()
        const userEntry = harem.find(entry => entry.characterId === randomCharacter.id)
        const statusMessage = randomCharacter.user 
            ? `تمت المطالبة به من قبل @${randomCharacter.user.split('@')[0]}` 
            : 'متاح'

        const message = `> ☄︎ الاسم *»* *${randomCharacter.name}*
> ᥫ᭡ النوع *»* *${randomCharacter.gender}*
> ✰ القيمة *»* *${randomCharacter.value}*
> ᰔᩚ الحالة *»* ${statusMessage}
> ✿ المصدر *»* *${randomCharacter.source}*
> ✦ المعرف: *${randomCharacter.id}*`

        const mentions = userEntry ? [userEntry.userId] : []
        await conn.sendFile(m.chat, randomImage, `${randomCharacter.name}.jpg`, message, m, { mentions })

        if (!randomCharacter.user) {
            await saveCharacters(characters)
        }

        cooldowns[userId] = now + 15 * 60 * 1000

    } catch (error) {
        await conn.reply(m.chat, `✘ حدث خطأ أثناء تحميل الشخصية: ${error.message}`, m)
    }
}

handler.help = ['رول']
handler.tags = ['gacha']
handler.command = ['رول'] // ← أمر عربي واحد فقط
handler.group = false
handler.register = true

export default handler