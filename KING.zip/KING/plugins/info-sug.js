let handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, `✦ من فضلك اكتب اقتراحك.`, m)
  if (text.length < 10) return conn.reply(m.chat, `✎ يجب أن يكون الاقتراح أكثر من 10 حروف.`, m)
  if (text.length > 1000) return conn.reply(m.chat, `❒ الحد الأقصى للاقتراح هو 1000 حرف.`, m)

  const nombre = await conn.getName(m.sender)
  const teks = `✏ اقتراح أمر جديد من المستخدم *${nombre}*

☊ الاقتراح:
> ${text}`

  await conn.reply(`201065826587@s.whatsapp.net`, m.quoted ? teks + '\n\n' + m.quoted.text : teks, m, {
    mentions: conn.parseMention(teks)
  })

  m.reply('✧ تم إرسال الاقتراح إلى مالك البوت.')
}

handler.help = ['اقتراح < نص الاقتراح >']
handler.tags = ['info']
handler.command = ['اقتراح']

export default handler