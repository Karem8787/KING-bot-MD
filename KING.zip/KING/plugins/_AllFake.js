import fs from 'fs'
import path from 'path'

export async function قبل(m, { conn }) {
  try {
    let اسم_البوت = global.namebot || 'بوت'
    let البانر_النهائي = 'https://raw.githubusercontent.com/AdonixServices/Files/main/1754310580366-xco6p1-1754310544013-6cc3a6.jpg'

    const رقم_البوت = conn.user?.jid?.split('@')[0].replace(/\D/g, '')
    const مسار_الاعدادات = path.join('./JadiBots', رقم_البوت, 'config.json')

    if (fs.existsSync(مسار_الاعدادات)) {
      try {
        const الاعدادات = JSON.parse(fs.readFileSync(مسار_الاعدادات))
        if (الاعدادات.name) اسم_البوت = الاعدادات.name
        if (الاعدادات.banner) البانر_النهائي = الاعدادات.banner
      } catch (err) {
        console.log('⚠️ لم يتم قراءة إعدادات البوت الفرعي في rcanal:', err)
      }
    }

    const القنوات = [global.idcanal, global.idcanal2]
    const قناة_عشوائية = القنوات[Math.floor(Math.random() * القنوات.length)]

    global.rcanal = {
      contextInfo: {
        isForwarded: true,
        forwardingScore: 1,
        forwardedNewsletterMessageInfo: {
          newsletterJid: قناة_عشوائية,
          serverMessageId: 100,
          newsletterName: اسم_البوت,
        },
        externalAdReply: {
          title: اسم_البوت,
          body: global.author,
          thumbnailUrl: البانر_النهائي,
          sourceUrl: '',
          mediaType: 1,
          renderLargerThumbnail: false
        }
      }
    }
  } catch (e) {
    console.log('حدث خطأ أثناء إنشاء متغير rcanal:', e)
  }
}