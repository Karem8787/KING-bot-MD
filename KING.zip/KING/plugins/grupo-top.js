import path from 'path'
let user = a => '@' + a.split('@')[0]

function handler(m, { groupMetadata, command, conn, text }) {
  if (!text) return conn.reply(m.chat, `📊 عن ماذا تريد التوب؟\n\nمثال: *${command} أكثر المستخدمين نشاطاً*`, m)

  let ps = groupMetadata.participants.map(v => v.id)
  let [a, b, c, d, e, f, g, h, i, j] = Array.from({ length: 10 }, () => ps.getRandom())

  let intro = pickRandom([
    `📊 *أفضل 10 في ${text.toUpperCase()}*`,
    `🏆 *ترتيب ${text}*`,
    `⭐ *قائمة الأكثر تميزاً في ${text}*`,
  ])

  let top = 
`${intro}

1. 🥇 ${user(a)}
2. 🥈 ${user(b)}
3. 🥉 ${user(c)}
4. 🎖️ ${user(d)}
5. ✨ ${user(e)}
6. 📌 ${user(f)}
7. 📈 ${user(g)}
8. 🔰 ${user(h)}
9. 🎯 ${user(i)}
10. 📍 ${user(j)}`

  conn.reply(m.chat, top, m, { mentions: [a, b, c, d, e, f, g, h, i, j] })
}

handler.help = ['توب *<النص>*']
handler.command = ['توب']
handler.tags = ['group']
handler.group = true
handler.register = true

export default handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}