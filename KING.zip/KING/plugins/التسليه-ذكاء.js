let handler = async (m, { conn }) => {

  let iq = Math.floor(Math.random() * 100) + 1 // رقم عشوائي من 1 إلى 100

  let target = m.mentionedJid && m.mentionedJid[0]

  // اختيار الجملة حسب مستوى الذكاء

  let reaction

  if (iq >= 90) {

    reaction = '🧠 عبقري بدرجة مرعبة!'

  } else if (iq >= 70) {

    reaction = '👏 ذكي وفاهم ما شاء الله!'

  } else if (iq >= 50) {

    reaction = '🙂 تمام بس محتاج تطور شوية'

  } else if (iq >= 30) {

    reaction = '🤕 حاول تقرأ كتب، يمكن تتحسن'

  } else {

    reaction = '😂 ربنا يشفيك'

  }

  let iqMessage = `*🤓  نسبة الذكاء 🤓*\n`

  if (target) {

    iqMessage += `*نسبة ذكاء @${target.split('@')[0]} 🤓هي* *"${iq}%"* *من 100%*\n`

  } else {

    iqMessage += `*نسبة ذكائك 🤓هي* *"${iq}%"* *من 100%*\n`

  }

  iqMessage += `*${reaction}*`

  await conn.sendMessage(m.chat, {

    text: iqMessage,

    mentions: target ? [target] : [m.sender]

  }, { quoted: m })

}

handler.help = ['ذكي']

handler.tags = ['fun']

handler.command = /^ذكي$/i

export default handler