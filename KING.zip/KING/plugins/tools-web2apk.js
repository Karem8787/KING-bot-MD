import axios from 'axios'

class Web2Apk {
  constructor() {
    this.baseURL = 'https://standalone-app-api.appmaker.xyz'
  }

  async startBuild(url, email) {
    try {
      const res = await axios.post(`${this.baseURL}/webapp/build`, { url, email })
      return res.data?.body?.appId
    } catch (err) {
      throw new Error('فشل بدء البناء: ' + err.message)
    }
  }

  async buildConfig(url, appID, appName) {
    try {
      const logo = 'https://logo.clearbit.com/' + url.replace('https://', '')
      const config = {
        appId: appID,
        appIcon: logo,
        appName: appName,
        isPaymentInProgress: false,
        enableShowToolBar: false,
        toolbarColor: '#03A9F4',
        toolbarTitleColor: '#FFFFFF',
        splashIcon: logo
      }

      const res = await axios.post(`${this.baseURL}/webapp/build/build`, config)
      return res.data
    } catch (err) {
      throw new Error('فشل إعداد البناء: ' + err.message)
    }
  }

  async getStatus(appID) {
    try {
      while (true) {
        const res = await axios.get(`${this.baseURL}/webapp/build/status?appId=${appID}`)
        if (res.data?.body?.status === 'success') return true
        await this.delay(5000)
      }
    } catch (err) {
      throw new Error('فشل جلب حالة البناء: ' + err.message)
    }
  }

  async getDownload(appID) {
    try {
      const res = await axios.get(`${this.baseURL}/webapp/complete/download?appId=${appID}`)
      return res.data
    } catch (err) {
      throw new Error('فشل جلب رابط التحميل: ' + err.message)
    }
  }

  async build(url, email, appName) {
    try {
      const appID = await this.startBuild(url, email)
      await this.buildConfig(url, appID, appName)
      await this.getStatus(appID)
      const download = await this.getDownload(appID)
      return download
    } catch (err) {
      throw err
    }
  }

  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  conn.web2apk = conn.web2apk || {}
  const id = m.chat

  if (!text) {
    return m.reply(`*🌐 محول موقع إلى APK*\n\nالاستخدام:\n${usedPrefix + command} <رابط> | <البريد الإلكتروني> | <اسم التطبيق>\n\nمثال:\n${usedPrefix + command} https://google.com | test@gmail.com | تطبيق جوجل\n\n⌛ الرجاء الانتظار بضع دقائق أثناء البناء.`)
  }

  let [url, email, appName] = text.split('|').map(s => s.trim())

  if (!url || !email || !appName)
    return m.reply(`❌ تنسيق غير صالح!\nالاستخدام الصحيح:\n${usedPrefix + command} <رابط> | <البريد الإلكتروني> | <اسم التطبيق>`)

  if (!url.startsWith('http://') && !url.startsWith('https://'))
    url = 'https://' + url

  if (!email.includes('@') || !email.includes('.'))
    return m.reply('❌ تنسيق البريد الإلكتروني غير صالح.')

  if (id in conn.web2apk)
    return m.reply('⚠️ هناك بناء جارٍ بالفعل. يرجى الانتظار حتى الانتهاء.')

  try {
    conn.web2apk[id] = true
    await m.reply(`🔧 *بدء بناء APK...*\n\n🌍 الرابط: ${url}\n📧 البريد الإلكتروني: ${email}\n📱 اسم التطبيق: ${appName}`)

    const builder = new Web2Apk()
    const result = await builder.build(url, email, appName)

    let downloadUrl = result?.body?.buildFile || result?.body?.downloadUrl || result?.body?.keyFile

    if (downloadUrl) {
      await m.reply(`✅ *تم البناء بنجاح!*\n\n📱 *التطبيق:* ${appName}\n🌐 *الموقع:* ${url}\n📥 *رابط التحميل:* ${downloadUrl}\n\n⏳ *الرابط صالح لمدة 24 ساعة*`)
    } else {
      await m.reply('❌ *فشل في الحصول على رابط التحميل.* يرجى المحاولة مرة أخرى.')
    }

  } catch (err) {
    await m.reply(`❌ *فشل البناء!*\n\n${err.message}\n\nالأسباب المحتملة:\n• رابط غير صالح\n• خادم API غير متاح\n• الموقع غير متوافق`)
  } finally {
    delete conn.web2apk[id]
  }
}

handler.help = ['تحويلapk']
handler.tags = ['tools']
handler.command = ['تحويلapk']

export default handler