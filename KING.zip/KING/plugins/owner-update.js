import { execSync } from 'child_process'
let handler = async (m, { conn, text }) => {
  await m.react('🕓')
  if (conn.user.jid == conn.user.jid) {
    let stdout = execSync('git pull' + (m.fromMe && text ? ' ' + text : ''))
    await conn.reply(m.chat, stdout.toString(), m, rcanal)
    await m.react('✅')
  }
}

handler.help = ['تحديث']
handler.tags = ['owner']
handler.command = ['تحديث'] // ← أضفنا أمر عربي واحد فقط
handler.rowner = false

export default handler