let handler = async (m, { conn, participants, command }) => {

  if (!m.isGroup) throw '❗هذا الأمر يعمل فقط داخل المجموعات'

  // استبعاد البوت والمرسل

  let others = participants.filter(p => p.id !== m.sender && !p.admin)

  if (others.length === 0) throw '❗لا يوجد أعضاء مناسبين للاختيار.'

  let random = others[Math.floor(Math.random() * others.length)].id

  let message = command === 'بيحبني'

    ? `❤️ @${random.split('@')[0]} هو أكــثر شخص بيـحبك فـي القروب!`

    : `💔 @${random.split('@')[0]} هو أكــثر شخص بيـكرهك فـي القروب!`

  await conn.sendMessage(m.chat, { text: message, mentions: [random] }, { quoted: m })

}

handler.help = ['بيحبني', 'بيكرهني']

handler.tags = ['fun']

handler.command = /^(بيحبني|بيكرهني)$/i

export default handler