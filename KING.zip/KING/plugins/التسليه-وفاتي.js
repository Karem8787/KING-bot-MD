let handler = async (m, { conn }) => {

  // توليد تاريخ وفاة عشوائي بين السنوات 2050 و 2080

  function randomDate() {

    const year = Math.floor(Math.random() * (2080 - 2050 + 1)) + 2050

    const month = Math.floor(Math.random() * 12) + 1

    const day = Math.floor(Math.random() * 28) + 1 // لتجنب تعقيدات شهور 30/31

    return `${day}-${month}-${year}`

  }

  // قائمة أسباب الوفاة عشوائية

  const reasons = [

    "الوقوع في حب القطط والتنفيس بجميع العقبات.",

    "الإفراط في مشاهدة الأنمي وعدم النوم.",

    "الإدمان على القهوة والكافيين.",

    "الضحك المستمر على نكت بايخة.",

    "السهر الطويل وعدم العناية بالصحة.",

    "الإفراط في تناول الشوكولاتة.",

    "الوقوع في حب القهوة والصداقة المزدوجة.",

    "الركض خلف الأحلام الوردية.",

    "تناول البيتزا يوميًا بدون توقف.",

    "الاستماع للأغاني الحزينة طوال الليل."

  ]

  let deathDate = randomDate()

  let reason = reasons[Math.floor(Math.random() * reasons.length)]

  const message = `

*❆━━━═⏣⊰🍄⊱⏣═━━━❆*

🍄⤺┇ *تاريخ الوفاة:* *${deathDate}*

*السبب:* 

*${reason}*

*❆━━━═⏣⊰🍄⊱⏣═━━━❆*

  `.trim()

  await conn.reply(m.chat, message, m)

}

handler.help = ['وفاتي']

handler.tags = ['fun']

handler.command = /^وفاتي$/i

export default handler