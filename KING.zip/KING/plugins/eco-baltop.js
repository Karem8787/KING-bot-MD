let handler = async (m, { conn, args, participants }) => {
    let users = Object.entries(global.db.data.users).map(([key, value]) => {
        return { ...value, jid: key };
    });

    let sortedLim = users.sort((a, b) => (b.coin || 0) + (b.bank || 0) - (a.coin || 0) - (a.bank || 0));
    let len = args[0] && args[0].length > 0 ? Math.min(10, Math.max(parseInt(args[0]), 10)) : Math.min(10, sortedLim.length);
    
    let text = `✦ قائمة أغنى المستخدمين بـ *${moneda}*\n\n`;

    text += sortedLim.slice(0, len).map(({ jid, coin, bank }, i) => {
        let total = (coin || 0) + (bank || 0);
        return `👑 *${i + 1}.* ${(participants.some(p => jid === p.jid) ? `@${jid.split`@`[0]}` : `wa.me/${jid.split`@`[0]}`)}\n` +
               `┗ 💰 إجمالي الرصيد: *${total} ${moneda}*`;
    }).join('\n');

    await conn.reply(m.chat, text.trim(), m, { mentions: conn.parseMention(text) });
}

handler.help = ['الأغنياء'];
handler.tags = ['eco'];
handler.command = ['الأغنياء']; // أمر واحد فقط باللغة العربية
handler.group = false;
handler.register = true;

export default handler;