import { promises as fs, existsSync } from 'fs'
import path from 'path'

var handler = async (m, { conn }) => {
  if (global.conn.user.jid !== conn.user.jid) {
    return conn.reply(m.chat, `❌ هذا الأمر مخصص فقط للرقم الرئيسي للبوت.`, m)
  }
  
  await conn.reply(m.chat, `⌛ جاري حذف ملفات الجلسة (باستثناء creds.json)...`, m)
  m.react('⌛') // تفاعل أثناء الانتظار

  const sessionPath = './sessions/'

  try {
    if (!existsSync(sessionPath)) {
      return conn.reply(m.chat, `📁 مجلد الجلسات غير موجود أو فارغ.`, m)
    }

    const files = await fs.readdir(sessionPath)
    let deletedCount = 0

    for (const file of files) {
      if (file !== 'creds.json') {
        await fs.unlink(path.join(sessionPath, file))
        deletedCount++
      }
    }

    if (deletedCount === 0) {
      await conn.reply(m.chat, `ℹ️ لا توجد ملفات لحذفها، فقط creds.json موجود.`, m)
    } else {
      m.react('✅') // تفاعل تم
      await conn.reply(m.chat, `✅ تم حذف ${deletedCount} ملف/ملفات جلسة، وترك creds.json كما هو.`, m)
      conn.reply(m.chat, `*مرحباً! هل تراني الآن؟*`, m)
    }
  } catch (error) {
    console.error('Error limpiando sesiones:', error)
    await conn.reply(m.chat, `⚠️ حدث خطأ أثناء عملية الحذف.`, m)
  }
}

handler.help = ['جلسةx']
handler.tags = ['owner']
// أضفنا أمر عربي واحد فقط بجانب الأوامر
handler.command = ['جلسةx']
handler.rowner = true

export default handler