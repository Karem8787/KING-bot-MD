import acrcloud from 'acrcloud'

let acr = new acrcloud({
  host: 'identify-eu-west-1.acrcloud.com',
  access_key: 'c33c767d683f78bd17d4bd4991955d81',
  access_secret: 'bvgaIAEtADBTbLwiPGYlxupWqkNGIjT7J9Ag2vIu'
})

let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || q.mediaType || ''
  if (/video|audio/.test(mime)) {
    let buffer = await q.download()
    let { status, metadata } = await acr.identify(buffer)
    if (status.code !== 0) throw status.msg 
    let { title, artists, album, genres, release_date } = metadata.music[0]
    let txt = '╭─⬣「 *أداة معرفة الموسيقى* 」⬣\n'
    txt += `│  ≡◦ *العنوان:* ${title}${artists ? `\n│  ≡◦ *الفنان:* ${artists.map(v => v.name).join(', ')}` : ''}`
    txt += `${album ? `\n│  ≡◦ *الألبوم:* ${album.name}` : ''}${genres ? `\n│  ≡◦ *النوع الموسيقي:* ${genres.map(v => v.name).join(', ')}` : ''}\n`
    txt += `│  ≡◦ *تاريخ الإصدار:* ${release_date}\n`
    txt += `╰─⬣`
    conn.reply(m.chat, txt, m)
  } else {
    return conn.reply(m.chat, `📢 الرجاء الرد على ملف صوتي أو فيديو قصير مع الأمر *${usedPrefix + command}* لمعرفة معلومات الموسيقى الموجودة.`, m)
  }
}

handler.help = ['معلوماتها <صوت/فيديو>']
handler.tags = ['tools']
handler.command = ['معلوماتها']
handler.register = true 
export default handler