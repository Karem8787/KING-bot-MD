import fetch from 'node-fetch';

let handler = async (m, { conn, args, usedPrefix, command }) => {
  let text = args.join(" ");
  if (!text) {
    return m.reply(
`🎧 *قم بإدخال وصف لإنشاء أغنية باستخدام الذكاء الاصطناعي!*

📌 *مثال ›* ${usedPrefix + command} راب حزين عن القطط
📝 كلما كان الوصف دقيقًا، كانت النتيجة أفضل.
`);
  }

  try {
    // تفاعل بالرمز أثناء التحميل
    await m.react('🕓');

    const res = await fetch(`https://myapiadonix.vercel.app/api/AImusic?prompt=${encodeURIComponent(text)}`);
    if (!res.ok) return m.reply("⚠️ تعذر إنشاء الموسيقى، حاول مرة أخرى لاحقًا.");

    const arrayBuffer = await res.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // إرسال الملف الصوتي للمستخدم
    await conn.sendFile(m.chat, buffer, 'اغنية-من-الذكاء-الاصطناعي.mp3',
`🎵 *تم إنشاء الأغنية بنجاح!*

🔹 *الوصف:* ${text}
🔊 *تم الإنشاء باستخدام الذكاء الاصطناعي*`, m);

  } catch (e) {
    console.error(e);
    m.reply("❌ حدث خطأ أثناء إنشاء الأغنية.");
  }
};

handler.help = ['اصنع'];
handler.tags = ['اصنع'];
handler.command = ['اصنع'];

export default handler;