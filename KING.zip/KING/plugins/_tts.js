import fetch from 'node-fetch'

let handler = async (m, { conn, args, command }) => {
  const vocesDisponibles = [
    'optimus_prime',
    'eminem',
    'taylor_swift',
    'nahida',
    'miku',
    'nami',
    'goku',
    'ana',
    'elon_musk',
    'mickey_mouse',
    'kendrick_lamar',
    'angela_adkinsh'
  ]

  if (args.length < 2) {
    return m.reply(`✐ الاستخدام الصحيح:\n.${command} <الصوت> <النص>\n\n❐ الأصوات المتاحة:\n${vocesDisponibles.join(', ')}`)
  }

  const voiceModel = args[0].toLowerCase()
  const text = args.slice(1).join(' ')

  if (!vocesDisponibles.includes(voiceModel)) {
    return m.reply(`✐ الصوت "${voiceModel}" غير موجود.\n❐ الأصوات المتاحة:\n${vocesDisponibles.join(', ')}`)
  }

  try {
    const res = await fetch(`https://zenzxz.dpdns.org/tools/text2speech?text=${encodeURIComponent(text)}`)
    const json = await res.json()

    if (!json.status || !Array.isArray(json.results)) {
      return m.reply('✦ حدث خطأ أثناء الحصول على البيانات من واجهة البرمجة.')
    }

    const voice = json.results.find(v => v.model === voiceModel)
    if (!voice || !voice.audio_url) {
      return m.reply('✿ لم يتم التمكن من توليد الصوت باستخدام هذا النموذج.')
    }

    const audioRes = await fetch(voice.audio_url)
    const audioBuffer = await audioRes.arrayBuffer()

    await conn.sendMessage(m.chat, {
      audio: Buffer.from(audioBuffer),
      mimetype: 'audio/mpeg',
      ptt: true
    }, { quoted: m })

  } catch (e) {
    console.error(e)
    m.reply('✐ حدث خطأ أثناء توليد الصوت.')
  }
}

handler.command = ['لصوت2']
handler.register = true
export default handler