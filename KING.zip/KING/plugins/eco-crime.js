let cooldowns = {}

let handler = async (m, { conn, text, command, usedPrefix }) => {
  let users = global.db.data.users
  let senderId = m.sender
  let senderName = conn.getName(senderId)

  let tiempo = 5 * 60 // 5 دقائق بالثواني
  if (cooldowns[senderId] && Date.now() - cooldowns[senderId] < tiempo * 1000) {
    let tiempo2 = segundosAHMS(Math.ceil((cooldowns[senderId] + tiempo * 1000 - Date.now()) / 1000))
    return m.reply(`🚨 لقد ارتكبت جريمة بالفعل! انتظر *${tiempo2}* قبل أن تحاول مرة أخرى.`)
  }
  cooldowns[senderId] = Date.now()

  let senderCoin = users[senderId].coin || 0
  let posiblesVictimas = Object.keys(users).filter(id => id !== senderId)
  if (posiblesVictimas.length === 0) return m.reply(`⚠ لا يوجد ضحايا للسرقة حالياً.`)

  let randomUserId = posiblesVictimas[Math.floor(Math.random() * posiblesVictimas.length)]
  let randomUserCoin = users[randomUserId].coin || 0

  let minAmount = 15
  let maxAmount = 50
  let amountTaken = Math.floor(Math.random() * (maxAmount - minAmount + 1)) + minAmount

  const moneda = '💰'

  const frases = {
    exito: [
      `✧ سرقت @${randomUserId.split("@")[0]} وأخذت *${amountTaken} ${moneda}*.`,
      `⚠ بخوف وسرعة خطفت *${amountTaken} ${moneda}* من @${randomUserId.split("@")[0]}.`,
      `❀ ضربته وسرقت *${amountTaken} ${moneda}*.`,
      `☄︎ كسرت وجه @${randomUserId.split("@")[0]} وسرقت *${amountTaken} ${moneda}*.`,
      `🔪 نفذت الهجوم وسرقت *${amountTaken} ${moneda}*.`,
      `💸 سرقت باحتراف وخرجت بـ *${amountTaken} ${moneda}*.`,
      `💀 نفذت عملية سرقة في الزاوية وأخذت *${amountTaken} ${moneda}*.`,
      `😈 استخدمت الخداع وسرقت *${amountTaken} ${moneda}*.`,
      `🧨 فجرت محفظته وأخذت *${amountTaken} ${moneda}*.`,
      `🔥 سرقته قبل أن يفهم ما حدث وأخذت *${amountTaken} ${moneda}*.`,
      `🐒 ضحكت عليه وسرقت *${amountTaken} ${moneda}*.`,
      `🎭 استخدمت قناع وسرقت *${amountTaken} ${moneda}*.`,
      `🚬 ظهرت فجأة وسرقت *${amountTaken} ${moneda}*.`,
      `🏃‍♂️ خدعته وسرقت *${amountTaken} ${moneda}*.`,
      `🧤 فتشت جيبه وسرقت *${amountTaken} ${moneda}* بدون ما يحس.`,
      `🕶 سرقت بكل أناقة *${amountTaken} ${moneda}*.`
    ],
    atrapado: [
      `⚠ تم القبض عليك وغرّموك *${amountTaken} ${moneda}*.`,
      `❀ الشرطة أمسكتك وخسرت *${amountTaken} ${moneda}*.`,
      `✧ تم اكتشافك وسرقوك *${amountTaken} ${moneda}*.`,
      `☄︎ تم الإمساك بك أثناء الجريمة وخسرت *${amountTaken} ${moneda}*.`,
      `🚓 الشرطة ألقت القبض عليك وسلبوك *${amountTaken} ${moneda}*.`,
      `👮‍♂️ تم ضربك من الشرطة وخسرت *${amountTaken} ${moneda}*.`,
      `🧱 اصطدمت بالخطأ وخسرت كل شيء.`,
      `🩻 تم تصويرك وأخذوا منك *${amountTaken} ${moneda}*.`,
      `🥴 ذهبت للمشفى وخسرت فلوسك.`,
      `🙃 وقعت أثناء الهروب وخسرت *${amountTaken} ${moneda}*.`,
      `🥵 سقط منك المال أثناء الهروب.`,
      `🚔 الشرطة وصلت وأخذت كل شيء.`,
      `💢 سيدة ضربتك بشنطتها وخسرت *${amountTaken} ${moneda}*.`
    ],
    semi: [
      `⚠ سرقت ولكن تم ملاحظتك، وأخذت فقط *${amountTaken} ${moneda}*.`,
      `❀ سرقة غير كاملة وحصلت على *${amountTaken} ${moneda}*.`,
      `✧ أخذت شيء بسيط وتم كشفك، فقط *${amountTaken} ${moneda}*.`,
      `☄︎ سرقة جزئية، حصلت على *${amountTaken} ${moneda}*.`,
      `🫥 ترددت لكن حصلت على *${amountTaken} ${moneda}*.`,
      `🥷 سرقة سريعة وحصلت على *${amountTaken} ${moneda}*.`,
      `😬 كنت متوتر، لكن حصلت على *${amountTaken} ${moneda}*.`,
      `💨 كنت سريع، أخذت *${amountTaken} ${moneda}*.`,
      `🤕 كدت تتعرض للضرب لكن هربت بـ *${amountTaken} ${moneda}*.`,
      `👟 ركضت بسرعة وأخذت *${amountTaken} ${moneda}*.`,
      `🐀 خطفت ما استطعت وهربت.`,
      `😅 نصف سرقة ونصف خوف، وحصلت على *${amountTaken} ${moneda}*.`,
      `🤡 كنت على وشك النجاح لكن كشفت نفسك، وأخذت ما أمكن.`
    ]
  }

  let randomOption = Math.floor(Math.random() * 3)

  switch (randomOption) {
    case 0:
      users[senderId].coin += amountTaken
      users[randomUserId].coin -= amountTaken
      await conn.sendMessage(m.chat, {
        text: frases.exito[Math.floor(Math.random() * frases.exito.length)],
        contextInfo: {
          mentionedJid: [randomUserId],
          ...global.rcanal
        }
      }, { quoted: m })
      break
    case 1:
      let amountSubtracted = Math.min(Math.floor(Math.random() * (senderCoin - minAmount + 1)) + minAmount, maxAmount)
      users[senderId].coin -= amountSubtracted
      await conn.sendMessage(m.chat, {
        text: frases.atrapado[Math.floor(Math.random() * frases.atrapado.length)],
        contextInfo: global.rcanal
      }, { quoted: m })
      break
    case 2:
      let smallAmountTaken = Math.min(Math.floor(Math.random() * (randomUserCoin / 2 - minAmount + 1)) + minAmount, maxAmount)
      users[senderId].coin += smallAmountTaken
      users[randomUserId].coin -= smallAmountTaken
      await conn.sendMessage(m.chat, {
        text: frases.semi[Math.floor(Math.random() * frases.semi.length)],
        contextInfo: {
          mentionedJid: [randomUserId],
          ...global.rcanal
        }
      }, { quoted: m })
      break
  }

  global.db.write()
}

handler.tags = ['eco']
handler.help = ['crime']
handler.command = ['جريمة', 'سرقة']
handler.register = true
handler.group = false

export default handler

function segundosAHMS(segundos) {
  let horas = Math.floor(segundos / 3600)
  let minutos = Math.floor((segundos % 3600) / 60)
  let segundosRestantes = segundos % 60
  return `${minutos} دقيقة و ${segundosRestantes} ثانية`
}