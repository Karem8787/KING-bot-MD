let cooldowns = {}

let handler = async (m, { conn, isPrems }) => {
  let user = global.db.data.users[m.sender]
  let tiempo = 5 * 60 // 5 دقائق

  if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < tiempo * 1000) {
    const tiempo2 = segundosAHMS(Math.ceil((cooldowns[m.sender] + tiempo * 1000 - Date.now()) / 1000))
    return conn.reply(m.chat, `⏳ لقد عملت مؤخرًا، انتظر *${tiempo2}* قبل أن تعمل مرة أخرى.`, m)
  }

  let rsl = Math.floor(Math.random() * 500)
  cooldowns[m.sender] = Date.now()
  user.coin += rsl

  await conn.reply(m.chat, `💼 ${pickRandom(trabajo)} *${toNum(rsl)}* ( *${rsl}* ) ${moneda} 💸.`, m)
}

handler.help = ['عمل']
handler.tags = ['eco']
handler.command = ['عمل'] // أمر عربي فقط
handler.group = false
handler.register = true

export default handler

function toNum(number) {
  if (number >= 1000 && number < 1000000) return (number / 1000).toFixed(1) + 'k'
  else if (number >= 1000000) return (number / 1000000).toFixed(1) + 'M'
  else if (number <= -1000 && number > -1000000) return (number / 1000).toFixed(1) + 'k'
  else if (number <= -1000000) return (number / 1000000).toFixed(1) + 'M'
  else return number.toString()
}

function segundosAHMS(segundos) {
  let minutos = Math.floor((segundos % 3600) / 60)
  let segundosRestantes = segundos % 60
  return `${minutos} دقيقة و ${segundosRestantes} ثانية`
}

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

const trabajo = [
  "✧ عملت كمصمم ميمز وأخذت",
  "✧ أصلحت الواي فاي لجارتك وأعطتك",
  "✧ اشتغلت دليفري على دراجة وكسبت",
  "✧ بعت فطائر على ناصية الشارع وربحت",
  "✧ ساعدت رجلًا أعمى لعبور الشارع فأعطاك",
  "✧ تنكرت كبوت وسليت الناس، فأعطوك",
  "✧ عملت كـ DJ في حفلة وأخذت",
  "✧ نظفت موبايل رجل بأصبعك وأعطاك",
  "✧ اشتغلت راعي قطط وأعطوك",
  "✧ ساعدت في حل واجب وأخذت مقابل",
  "✧ بعت ملصقات في القروب وربحت",
  "✧ برمجت بوتات فريلانسر وأخذت",
  "✧ عملت مقدمة فيديو ليوتيوبر وأعطاك",
  "✧ ساعدت في السوق وأخذت مقابل",
  "✧ لعبت دور شخصية NPC في تطبيق ذكاء صناعي وأعطوك",
  "✧ تنكرت في زي بيكاتشو ورمو لك",
  "✧ اشتغلت سباك يوم كامل وربحت",
  "✧ عملت كعك مع جدتك وأخذت",
  "✧ أصلحت واتساب لجارة وأعطتك",
  "✧ صنعت ميمز مشهورة وأخذت أجر الشهرة",
  "✧ أصلحت أجهزة قديمة وربحت",
  "✧ علمت طفل كيف يلعب ماينكرافت وأعطاك",
  "✧ كنت حكمًا في مسابقة رقص وربحت",
  "✧ اشتغلت في بار تقدم عصائر وأخذت",
  "✧ بعت صور ذكاء صناعي مميزة وأعطوك",
]