import fetch from 'node-fetch';

let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text) return m.reply(`✐ الرجاء إدخال نص للبحث في يوتيوب\n> *مثال:* ${usedPrefix + command} اوزونا`);

  try {
    let api = await (await fetch(`https://delirius-apiofc.vercel.app/search/ytsearch?q=${encodeURIComponent(text)}`)).json();
    if (!api.data || !api.data.length) return m.reply('❌ لم يتم العثور على نتائج للبحث.');

    let results = api.data[0];

    // التحقق من مدة الفيديو
    if (results.duration === '0:00' || results.duration === '0.00' || !results.duration) {
      return m.reply('❌ مدة الفيديو 0:00 ولا يمكن تنزيله.');
    }

    let txt = `*「✦」 ${results.title}*\n\n` +
              `> ✦ *القناة:* ${results.author?.name || 'غير معروف'}\n` +
              `> ⴵ *المدة:* ${results.duration || 'غير معروفة'}\n` +
              `> ✰ *المشاهدات:* ${results.views || 'غير معروفة'}\n` +
              `> ✐ *تاريخ النشر:* ${results.publishedAt || 'غير معروف'}\n` +
              `> 🜸 *الرابط:* ${results.url || 'غير متوفر'}`;

    // إرسال المعلومات إلى الخاص
    let senderJid = m.sender;
    let img = results.image || null;

    if (img) {
      await conn.sendMessage(senderJid, { image: { url: img }, caption: txt }, { quoted: m });
    } else {
      await conn.sendMessage(senderJid, { text: txt }, { quoted: m });
    }

    // تحميل الصوت بسرعة
    let api2 = await (await fetch(`https://theadonix-api.vercel.app/api/ytmp3?url=${encodeURIComponent(results.url)}`)).json();

    if (!api2.result || !api2.result.audio) {
      return m.reply('❌ لم يتمكن من الحصول على صوت الفيديو.');
    }

    // إرسال الصوت إلى القناة
    let canal = '120363422248474738@newsletter';
    try {
      await conn.sendMessage(canal, {
        audio: { url: api2.result.audio },
        mimetype: 'audio/mpeg',
        ptt: true
      });

      await m.reply('✅ تم إرسال الصوت إلى القناة بنجاح.');
    } catch (err) {
      await m.reply('❌ فشل في إرسال الصوت إلى القناة.');
    }

  } catch (e) {
    m.reply(`❌ خطأ: ${e.message}`);
    await m.react('✖️');
  }
};

// دعم أمر عربي "تشغيلقناة" بجانب playch
handler.command = ['قناة_تشغيل'];
export default handler;