let partidas = {}

const handler = async (m, { conn, args }) => {
    const niveles = ['facil', 'medio', 'dificil', 'extremo']

    if (!partidas[m.sender] && args[0] && niveles.includes(args[0].toLowerCase())) {
        let nivel = args[0].toLowerCase()
        let num1, num2, operador, emoji, nombreOperacion, respuesta

        switch (nivel) {
            case 'facil':
                num1 = Math.floor(Math.random() * 10) + 1
                num2 = Math.floor(Math.random() * 10) + 1
                operador = ['+', '-'][Math.floor(Math.random() * 2)]
                break
            case 'medio':
                num1 = Math.floor(Math.random() * 20) + 5
                num2 = Math.floor(Math.random() * 20) + 5
                operador = ['+', '-', '*'][Math.floor(Math.random() * 3)]
                break
            case 'dificil':
                num1 = Math.floor(Math.random() * 50) + 10
                num2 = Math.floor(Math.random() * 50) + 10
                operador = ['+', '-', '*', '/'][Math.floor(Math.random() * 4)]
                break
            case 'extremo':
                num1 = Math.floor(Math.random() * 100) + 20
                num2 = Math.floor(Math.random() * 100) + 20
                operador = ['+', '-', '*', '/'][Math.floor(Math.random() * 4)]
                break
        }

        if (operador === '/') num1 = num1 * num2

        if (operador === '+') { emoji = '➕'; nombreOperacion = 'جمع' }
        if (operador === '-') { emoji = '➖'; nombreOperacion = 'طرح' }
        if (operador === '*') { emoji = '✖️'; nombreOperacion = 'ضرب' }
        if (operador === '/') { emoji = '➗'; nombreOperacion = 'قسمة' }

        respuesta = eval(`${num1} ${operador} ${num2}`)

        partidas[m.sender] = {
            respuesta,
            jugador: m.sender,
            intentos: 0
        }

        return conn.sendMessage(m.chat, { 
            text: `🎯 *تحدي رياضي (${nivel.toUpperCase()})*\n\n${emoji} *${nombreOperacion}*\n\`${num1} ${operador} ${num2}\`\n\n✏️ أجب باستخدام:\n\`.matematicas [إجابتك]\`\n\n⚠️ فقط ${m.pushName} يمكنه الإجابة\n📌 لديك *3 محاولات*`
        }, { quoted: m })
    }

    if (partidas[m.sender]) {
        if (!args[0]) return m.reply("📌 اكتب إجابتك بعد الأمر `.matematicas`")
        let intento = Number(args[0])
        if (isNaN(intento)) return m.reply("❌ الرجاء إدخال رقم صحيح")

        let partida = partidas[m.sender]
        partida.intentos++

        if (intento === partida.respuesta) {
            delete partidas[m.sender]
            return m.reply(`✅ صحيح يا ${m.pushName}! الإجابة كانت ${partida.respuesta}`)
        } else {
            if (partida.intentos >= 3) {
                delete partidas[m.sender]
                return conn.sendMessage(m.chat, {
                    text: `❌ خسرت جميع المحاولات يا ${m.pushName}!\n💡 الإجابة الصحيحة كانت: *${partida.respuesta}*`,
                    buttons: [
                        { buttonId: `.matematicas facil`, buttonText: { displayText: "🔄 العب مرة أخرى" }, type: 1 }
                    ],
                    headerType: 1
                }, { quoted: m })
            } else {
                return m.reply(`⚠️ خطأ يا ${m.pushName}! تبقى لك *${3 - partida.intentos}* محاولات`)
            }
        }
    }

    return m.reply(`📚 استخدم:\n\`.matematicas [المستوى]\`\n\n*المستويات المتاحة:*\n- سهل\n- متوسط\n- صعب\n- متطرف\n\nمثال: \`.matematicas facil\``)
}

handler.help = ['الرياضيات']
handler.tags = ['game']
handler.command = /^الرياضيات$/i

export default handler