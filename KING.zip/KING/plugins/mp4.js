import axios from 'axios'

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('📎 من فضلك أرسل رابط فيديو يوتيوب')

  try {
    // طلب إلى API الخاص بك
    const apiUrl = `https://myapiadonix.vercel.app/api/hd?url=${encodeURIComponent(text)}`
    const res = await axios.get(apiUrl)

    if (!res.data || !res.data.success) {
      return m.reply('❌ لم يتم العثور على الفيديو أو حدث خطأ في API')
    }

    const { title, download } = res.data.data

    // إرسال الفيديو مباشرة
    await conn.sendMessage(m.chat, {
      video: { url: download },
      caption: `🎬 *${title}*`,
      mimetype: 'video/mp4'
    }, { quoted: m })

  } catch (error) {
    console.error(error)
    m.reply('⚠️ حدث خطأ أثناء جلب أو إرسال الفيديو، حاول لاحقاً')
  }
}

// أضفنا دعم أمر عربي واحد فقط بجانب mp4
handler.command = /^mp4|mp4$/i

export default handler