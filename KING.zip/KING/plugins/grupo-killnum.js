let handler = async (m, { conn, args }) => {
  if (!m.isGroup) return m.reply('❌ هذا الأمر يعمل فقط في المجموعات.');

  if (!args[0]) return m.reply('✿ *الاستخدام الصحيح ›* .kicknum +212 أو .kicknum 212');

  let prefix = args[0].replace(/\D/g, ''); // فقط الأرقام من الكود

  if (!prefix) return m.reply('❌ يجب إدخال كود دولة صحيح، مثال: 212');

  try {
    let metadata = await conn.groupMetadata(m.chat);
    let participants = metadata.participants.map(p => p.id);
    let toKick = participants.filter(user => user.startsWith(prefix));

    if (toKick.length === 0) return m.reply(`✿ لم أجد مستخدمين يبدأ رقمهم بـ +${prefix} في المجموعة.`);

    for (let user of toKick) {
      try {
        await conn.groupParticipantsUpdate(m.chat, [user], 'remove');
      } catch {}
    }

    let list = toKick.map(u => `@${u.split('@')[0]}`).join('\n');
    m.reply(`✿ تم طرد المستخدمين الذين يبدأ رقمهم بـ +${prefix}:\n${list}`, null, { mentions: toKick });

  } catch (e) {
    console.error(e);
    m.reply('❌ حدث خطأ أثناء محاولة طرد المستخدمين.');
  }
}

handler.command = ['برا'];
handler.help = ['برا'];
handler.tags = ['group'];
handler.admin = true;

export default handler;