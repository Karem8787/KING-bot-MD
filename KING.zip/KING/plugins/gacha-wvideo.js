import { promises as fs } from 'fs'

const charactersFilePath = './database/characters.json'
const haremFilePath = './database/harem.json'

async function loadCharacters() {
  try {
    const data = await fs.readFile(charactersFilePath, 'utf-8')
    return JSON.parse(data)
  } catch (error) {
    throw new Error('✎ لم نتمكن من تحميل ملف *characters.json*.')
  }
}

async function loadHarem() {
  try {
    const data = await fs.readFile(haremFilePath, 'utf-8')
    return JSON.parse(data)
  } catch (error) {
    return []
  }
}

let handler = async (m, { conn, command, args }) => {
  if (!args.length) {
    return conn.sendMessage(m.chat, {
      text: `
ꕥ يجب عليك كتابة اسم شخصية.
> ● *مثال ›* ${command} Roxy Migurdia
`.trim(),
      ...global.rcanal
    }, { quoted: m })
  }

  const characterName = args.join(' ').toLowerCase().trim()

  try {
    const characters = await loadCharacters()
    const character = characters.find(c => c.name.toLowerCase() === characterName)

    if (!character) {
      return conn.sendMessage(m.chat, {
        text: `
✎ لم يتم العثور على › *${characterName}*
> ❒ تأكد من كتابة الاسم بشكل صحيح
`.trim(),
        ...global.rcanal
      }, { quoted: m })
    }

    if (!character.vid || !character.vid.length) {
      return conn.sendMessage(m.chat, {
        text: `
✎ لا توجد فيديوهات مسجلة لـ › *${character.name}*
> ❒ جرب شخصية أخرى
`.trim(),
        ...global.rcanal
      }, { quoted: m })
    }

    const randomVideo = character.vid[Math.floor(Math.random() * character.vid.length)]
    const caption = `
✩ الاسم › *${character.name}*
✿ النوع › *${character.gender}*
❒ المصدر › *${character.source}*
`.trim()

    const sendAsGif = Math.random() < 0.5
    await conn.sendMessage(m.chat, {
      video: { url: randomVideo },
      gifPlayback: sendAsGif,
      caption,
      ...global.rcanal
    }, { quoted: m })

  } catch (error) {
    await conn.sendMessage(m.chat, {
      text: `
✘ حدث خطأ أثناء تحميل الفيديو › ${error.message}
> ❒ حاول مرة أخرى لاحقًا
`.trim(),
      ...global.rcanal
    }, { quoted: m })
  }
}

handler.help = ['فيديو_شخصيه']
handler.tags = ['gacha']
handler.command = ['فيديو_شخصيه'] // ← أضفنا الأمر العربي
handler.register = true

export default handler