/*
@ Converter file to Url
@ supported uploaded all files

# by : ⛊  𝚂𝙰𝚈𝙴𝙳-𝚂𝙷𝙰𝚆𝙰𝚉𝙰
# channel : https://whatsapp.com/channel/0029Vb5u2oNJ3juwGBYtXF1G
# website : https://stitch-api.vercel.app
*/

import axios from 'axios'
import fetch from 'node-fetch'
import FormData from 'form-data'
import { fileTypeFromBuffer } from 'file-type'

let handler = async (m, { conn }) => {

 try {
    
 let q = m.quoted ? m.quoted : m
 let mime = (q.msg || q).mimetype || q.mediaType || ''
	
 if (!mime || mime == 'conversation') return m.reply('Reply to the first file')
	
 let media = await q.download();
        
 let { name, url, size, path } = await uploadFile(media);
 
        
 let caption = `
╭─ 「 UPLOAD SUCCESS 」──
 
 Name: ${name}
 
 Size: ${size}
 
 Path: ${path}
 
 URL: ${url}
 
╰──────────────────`;

await conn.reply(m.chat, caption, m);


 } catch (error) {
   await conn.reply(m.chat, `Error: ${error.message || error}`, m);
 }
}

handler.help = ['tourl']
handler.tags = ['tools']
handler.command = /^(ارفع|upload)$/i

export default handler;

async function uploadFile(buffer) {
  try {
  
  const { ext, mime } = (await fileTypeFromBuffer(buffer)) || { ext: 'bin', mime: 'application/octet-stream' };
  
  const type = mime.split('/')[0];
  
  const fileName = type + Math.random().toString(36).substring(8, 35) + '.' + ext;
  
  const form = new FormData();
  form.append('file', buffer, { filename: fileName, contentType: mime });
  
  const res = await fetch('https://stitch-api.vercel.app/api/v3/upload', {
  method: 'POST',
  body: form,
  headers: form.getHeaders?.() || {},
  });
  
  const json = await res.json();
  
  if (!json.status) throw new Error('Upload failed'); 
  
  const { name, url, size, path } = json.file;

  return { name, url, size, path };
  
  } catch (error) {
    console.error('Error uploading:', error.message);
    throw new Error(error.message);
  }

}