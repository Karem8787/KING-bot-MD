// plugins/daradmin.js
const daradmin = async (m, { conn, isOwner }) => {
  try {
    const chatId = m.chat
    if (!chatId.endsWith('@g.us')) return m.reply('⚠️ هذا الأمر يشتغل فقط في المجموعات.')

    await conn.sendMessage(chatId, { react: { text: '🔥', key: m.key } })

    const groupMetadata = await conn.groupMetadata(chatId)
    const senderId = m.sender
    const senderParticipant = groupMetadata.participants.find(p => p.id === senderId)
    const isSenderAdmin = senderParticipant && (senderParticipant.admin === 'admin' || senderParticipant.admin === 'superadmin')

    if (!isSenderAdmin && !isOwner) {
      return m.reply('⚠️ فقط المديرين أو صاحب المجموعة يمكنهم رفع الأعضاء كمديرين.')
    }

    let targetId = m.quoted?.sender || (m.mentionedJid && m.mentionedJid[0])
    if (!targetId) {
      return m.reply('⚠️ يجب الرد على رسالة عضو أو منشنه لرفعه مدير.')
    }

    await conn.groupParticipantsUpdate(chatId, [targetId], 'promote')
    await conn.sendMessage(chatId, {
      text: `✅ تم رفع @${targetId.split('@')[0]} كمدير في المجموعة.`,
      mentions: [targetId]
    }, { quoted: m })

    await conn.sendMessage(chatId, { react: { text: '✅', key: m.key } })
  } catch (e) {
    console.error('❌ خطأ في أمر رفع مدير:', e)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء محاولة رفع المدير.' }, { quoted: m })
  }
}

daradmin.command = /^(daradmin|daradmins|ادمن)$/i
daradmin.help = ['ادمن']
daradmin.tags = ['group']
export default daradmin