import axios from 'axios';

const handler = async (m, { conn }) => {
  try {
    const res = await axios.get('https://g-mini-ia.vercel.app/api/meme');
    const memeUrl = res.data.url;

    if (!memeUrl) {
      return m.reply('❌ لا يمكن الحصول على الميم.');
    }

    await conn.sendMessage('120363422248474738@newsletter', {
      image: { url: memeUrl },
      caption: '> ❀ *ميم اليوم*',
    });

    m.reply('🔥 تم إرسال الميم إلى القناة.');
  } catch (e) {
    console.error(e);
    m.reply('⚠️ حدث خطأ أثناء إرسال الميم.');
  }
};

handler.command = ['ميم_ارسل']; // ← أضفنا اسم عربي واحد فقط
handler.help = ['ميم_ارسل'];
handler.tags = ['owner'];
handler.rowner = true;

export default handler;