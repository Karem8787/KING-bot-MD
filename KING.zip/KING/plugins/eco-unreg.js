let handler = async (m, { conn, text }) => {
  let user = global.db.data.users[m.sender]
  user.registered = false
  return conn.reply(m.chat, `⭐ تم حذف تسجيلك من قاعدة البيانات.`, m)
}

handler.help = ['الغاء']
handler.tags = ['eco']
handler.command = ['الغاء'] // اسم الأمر العربي الوحيد
handler.register = true

export default handler