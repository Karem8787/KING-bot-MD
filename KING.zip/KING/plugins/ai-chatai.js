/**
 * تم الإنشاء بواسطة Ado-rgb
 * Repo: github.com/Ado-rgb
 * لا تقم بإزالة حقوق الملكية
 */

import axios from 'axios';

const MODELOS = {
  'ChatGPT-4o': 'chatgpt-4o',
  'ChatGPT-4o Mini': 'chatgpt-4o-mini',
  'Claude 3 Opus': 'claude-3-opus',
  'Claude 3.5 Sonnet': 'claude-3-sonnet',
  'Llama 3': 'llama-3',
  'Llama 3.1 (Pro)': 'llama-3-pro',
  'Perplexity AI': 'perplexity-ai',
  'Mistral Large': 'mistral-large',
  'Gemini 1.5 Pro': 'gemini-1.5-pro'
};

async function استشارة_الذكاء_الاصطناعي(السؤال, النموذج_المختار) {
  const النموذج = MODELOS[النموذج_المختار];
  if (!النموذج) return `❌ النموذج "${النموذج_المختار}" غير متاح حالياً.`;

  try {
    const { data } = await axios.post(
      'https://whatsthebigdata.com/api/ask-ai/',
      {
        message: السؤال,
        model: النموذج,
        history: []
      },
      {
        headers: {
          'content-type': 'application/json',
          'origin': 'https://whatsthebigdata.com',
          'referer': 'https://whatsthebigdata.com/ai-chat/',
          'user-agent': 'Mozilla/5.0'
        }
      }
    );

    if (data?.text) {
      return `🔰 *النموذج:* ${النموذج_المختار}\n📌 *سؤالك:* ${السؤال}\n\n${data.text}`;
    }

    return '⚠️ لم يتم الحصول على رد من الذكاء الاصطناعي.';
  } catch (e) {
    return `⚠️ *خطأ:* ${
      e.response?.status === 400
        ? 'تم رفض المحتوى من قبل النموذج.'
        : e.message
    }`;
  }
}

let handler = async (m, { args, text }) => {
  if (!text) {
    return m.reply(
`⚙️ *الاستخدام الصحيح:*
${usedPrefix}chatai [اسم النموذج اختياري] [سؤالك]

🔎 *أمثلة:*
${usedPrefix}ai ما هي الذكاء الاصطناعي؟
${usedPrefix}ai ChatGPT-4o اشرح نظرية الكم

🧠 *النماذج المتاحة:*
${Object.keys(MODELOS).join(', ')}`);
  }

  let النموذج_المختار = 'Claude 3.5 Sonnet';
  let السؤال = text;

  const أول_كلمة = args[0];
  if (MODELOS[أول_كلمة]) {
    النموذج_المختار = أول_كلمة;
    السؤال = args.slice(1).join(' ');
    if (!السؤال) return m.reply('⚠️ يجب عليك كتابة سؤال بعد اختيار النموذج.');
  }

  const الرد = await استشارة_الذكاء_الاصطناعي(السؤال, النموذج_المختار);
  m.reply(رد);
};

handler.help = ['ai <النموذج> <سؤالك>'];
handler.tags = ['الذكاء_الاصطناعي'];
handler.command = ['ai', 'جي', 'اسأل']; // دعم أوامر عربية + الإنجليزية

export default handler;