import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, `هل لديك سؤال؟ شاركني به :D`, m, global.rcanal)

  await m.react('💬')

  try {
    let api = await fetch(`https://api-pbt.onrender.com/api/ai/model/deepseek?texto=${encodeURIComponent(text)}&apikey=8jkh5icbf05`)
    let json = await api.json()

    if (json?.data) {
      await conn.reply(m.chat, json.data.trim(), m, global.rcanal)
    } else {
      await m.react('✖️')
    }
  } catch {
    await m.react('✖️')
  }
}

handler.help = ['ديبسك']
handler.tags = ['tools']
// إضافة أمر عربي واحد فقط 'ديبسك' مع الأوامر الأصلية
handler.command = /^(deep|deepseek|deeps|ديبسك)$/i
handler.register = true

export default handler