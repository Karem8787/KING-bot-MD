import { promises as fs } from 'fs';

const charactersFilePath = './database/characters.json';
const haremFilePath = './database/harem.json';
const cooldowns = {};

async function loadCharacters() {
  const data = await fs.readFile(charactersFilePath, 'utf-8');
  return JSON.parse(data);
}

async function saveCharacters(data) {
  await fs.writeFile(charactersFilePath, JSON.stringify(data, null, 2), 'utf-8');
}

async function loadHarem() {
  try {
    const data = await fs.readFile(haremFilePath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return {};
  }
}

async function saveHarem(data) {
  await fs.writeFile(haremFilePath, JSON.stringify(data, null, 2), 'utf-8');
}

let handler = async (m, { conn }) => {
  const userId = m.sender;
  const now = Date.now();

  if (cooldowns[userId] && now < cooldowns[userId]) {
    const remainingTime = Math.ceil((cooldowns[userId] - now) / 1000);
    const min = Math.floor(remainingTime / 60);
    const sec = remainingTime % 60;
    return await conn.reply(m.chat, `⏳ يجب أن تنتظر *${min} دقيقة و${sec} ثانية* قبل استخدام الأمر مرة أخرى.`, m);
  }

  if (!m.quoted || m.quoted.sender !== conn.user.jid) {
    return await conn.reply(m.chat, '⚠️ يجب أن ترد على شخصية تم إرسالها من البوت.', m);
  }

  const characterIdMatch = m.quoted.text.match(/ID:\s?\*(.+?)\*/);
  if (!characterIdMatch) {
    return await conn.reply(m.chat, '🚫 لم يتم العثور على معرف صحيح في الرسالة.', m);
  }

  const characterId = characterIdMatch[1];

  try {
    const characters = await loadCharacters();
    const harem = await loadHarem();

    const character = characters.find(c => c.id === characterId);
    if (!character) {
      return await conn.reply(m.chat, '❌ الشخصية بهذا المعرف غير موجودة.', m);
    }

    if (character.user && character.user !== userId) {
      return await conn.reply(
        m.chat,
        `⚠️ هذه الشخصية تم المطالبة بها من قبل @${character.user.split('@')[0]}`,
        m,
        { mentions: [character.user] }
      );
    }

    character.user = userId;
    character.status = 'تمت المطالبة';

    if (!harem[userId]) harem[userId] = [];
    if (!harem[userId].some(p => p.id === character.id)) {
      harem[userId].push(character);
    }

    await saveCharacters(characters);
    await saveHarem(harem);

    cooldowns[userId] = now + 30 * 60 * 1000;

    await conn.reply(m.chat, `🎉 لقد طالبت بالشخصية *${character.name}* بنجاح!`, m);

  } catch (err) {
    console.error(err)
    await conn.reply(m.chat, `❗ حدث خطأ أثناء المطالبة: ${err.message}`, m);
  }
};

handler.help = ['مطالبة'];
handler.tags = ['gacha'];
handler.command = ['مطالبة'];
handler.group = false;
handler.register = true;
export default handler;