//--> تم بواسطة Ado-rgb (github.com/Ado-rgb)
// •|• من فضلك لا تزيل حقوق المبرمج..
import fetch from 'node-fetch';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`✐ *الاستخدام الصحيح:* ${usedPrefix + command} النص الذي تريد تحويله إلى صوت`);

    try {
        let url = `https://api.nekorinn.my.id/tools/openai-tts?text=${encodeURIComponent(text)}&voice=nova`;
        let res = await fetch(url);

        if (!res.ok) throw new Error(`خطأ في الاتصال: HTTP ${res.status}`);
        let audioBuffer = await res.arrayBuffer();

        await conn.sendMessage(m.chat, {
            audio: Buffer.from(audioBuffer),
            mimetype: 'audio/mpeg',
            ptt: true
        }, { quoted: m });
    } catch (e) {
        m.reply(`❌ *حدث خطأ أثناء توليد الصوت:* ${e.message}`);
    }
};

handler.help = ['لصوت <النص>'];
handler.tags = ['tools'];
handler.command = ['لصوت']; // يمكنك تغييره لأي اسم آخر بالعربي

export default handler;