let cooldowns = {}

let handler = async (m, { conn, text, command, usedPrefix }) => {
  let users = global.db.data.users
  let senderId = m.sender
  let senderName = await conn.getName(senderId)
  let moneda = global.moneda || '💸'

  let tiempo = 5 * 60
  if (cooldowns[senderId] && Date.now() - cooldowns[senderId] < tiempo * 1000) {
    let tiempo2 = segundosAHMS(Math.ceil((cooldowns[senderId] + tiempo * 1000 - Date.now()) / 1000))
    return m.reply(`✦ تستخدم هذا الأمر كثيرًا، انتظر *${tiempo2}* قبل إعادة استخدام *#عاهرة*.`)
  }

  cooldowns[senderId] = Date.now()

  let senderCoin = users[senderId].coin || 0
  let randomUserId = Object.keys(users)[Math.floor(Math.random() * Object.keys(users).length)]
  while (randomUserId === senderId) {
    randomUserId = Object.keys(users)[Math.floor(Math.random() * Object.keys(users).length)]
  }

  let randomUserCoin = users[randomUserId].coin || 0
  let minAmount = 15
  let maxAmount = 50
  let amountTaken = Math.floor(Math.random() * (maxAmount - minAmount + 1)) + minAmount
  let randomOption = Math.floor(Math.random() * 14)

  const frases = [
    `✦ راودت @${randomUserId.split("@")[0]} بذكاء حتى انهار 😩\n➩ ربحت *${amountTaken} ${moneda}*`,
    `✦ صفعت @${randomUserId.split("@")[0]} على المؤخرة فصرخ "آه يا بابا" 🔥\n➩ *+${amountTaken} ${moneda}*`,
    `✦ أبهرت @${randomUserId.split("@")[0]} بأسلوبك الجريء 🤤\n➩ دفع لك *${amountTaken} ${moneda}*`,
    `✦ استخدمت مهارات مزدوجة مع @${randomUserId.split("@")[0]} حتى صُدم 🤯\n➩ *${amountTaken} ${moneda}*`,
    `✦ جعلت @${randomUserId.split("@")[0]} يشعر بالدوار من الأداء 💀\n➩ *+${amountTaken} ${moneda}*`,
    `✦ قمت برقصة مثيرة لـ @${randomUserId.split("@")[0]} في الشارع 🥵\n➩ أعطاك *${amountTaken} ${moneda}*`,
    `✦ انحنيت بإغراء و @${randomUserId.split("@")[0]} لم يتردد 🤯\n➩ سقط منك *${amountTaken} ${moneda}*`,
    `✦ لعقت سُرّة @${randomUserId.split("@")[0]} فجأة 💦\n➩ ترك لك *${amountTaken} ${moneda}*`,
    `✦ تم ربطك على كرسي من قبل @${randomUserId.split("@")[0]} وتلقيت الأجر 🪢\n➩ *+${amountTaken} ${moneda}*`,
    `✦ تم تصويرك مع @${randomUserId.split("@")[0]} 📸\n➩ أصبحت ترند وربحت *${amountTaken} ${moneda}*`,
    `✦ قمت بعلاقة سريعة في الحمام مع @${randomUserId.split("@")[0]} 🧻\n➩ حصلت على *${amountTaken} ${moneda}*`,
    `✦ أبهرت @${randomUserId.split("@")[0]} بحركات غريبة 🤸‍♂️\n➩ منحك *${amountTaken} ${moneda}*`,
    `✦ جعلك @${randomUserId.split("@")[0]} تتخذ وضعيات غريبة وأُعجب بك 🤕\n➩ ربحت *${amountTaken} ${moneda}*`,
    `✦ تظاهرت بأنك دليفري وقدمت الخدمة لـ @${randomUserId.split("@")[0]} 🍆📦\n➩ *${amountTaken} ${moneda}*`,
  ]

  const frasesFail = [
    `✦ عضضت الزبون بالخطأ وتعرضت لدعوى قضائية 😭\n➩ خسرت ${moneda}`,
    `✦ الزبون تقيأ من هول المنظر 💩\n➩ تم خصم ${moneda}`,
    `✦ سقطت فوق الزبون ودفعت تكاليف المستشفى 🏥\n➩ خُصم منك ${moneda}`,
    `✦ لم تستحم وكنت تفوح 💩\n➩ تم إلغاء الخدمة وخصم ${moneda}`,
    `✦ بدأت تحكي عن حبيبك السابق أثناء العمل 💔\n➩ تم حظرك وخسرت ${moneda}`,
  ]

  switch (randomOption) {
    case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
    case 8: case 9: case 10: case 11: case 12: case 13:
      users[senderId].coin += amountTaken
      users[randomUserId].coin -= amountTaken
      conn.sendMessage(m.chat, {
        text: frases[randomOption],
        mentions: [randomUserId],
        ...global.rcanal
      }, { quoted: m })
      break

    default:
      let amountSubtracted = Math.min(Math.floor(Math.random() * (senderCoin - minAmount + 1)) + minAmount, maxAmount)
      users[senderId].coin -= amountSubtracted
      m.reply(`${frasesFail.random()}\n\n➩ تم خصم *-${amountSubtracted} ${moneda}* من ${senderName}`)
      break
  }

  global.db.write()
}

handler.tags = ['eco']
handler.help = ['عاهرة']
handler.command = ['عاهرة'] // اسم الأمر الوحيد المعرّب
handler.register = true
handler.group = false

export default handler

function segundosAHMS(segundos) {
  let minutos = Math.floor((segundos % 3600) / 60)
  let segundosRestantes = segundos % 60
  return `${minutos}m ${segundosRestantes}s`
}

Array.prototype.random = function () {
  return this[Math.floor(Math.random() * this.length)]
}