var handler = async (m, { conn, args }) => {
    if (!m.isGroup) return m.reply('🔒 هذا الأمر يستخدم فقط في المجموعات.');

    const groupMetadata = await conn.groupMetadata(m.chat);

    // عرض معلومات المشاركين وأدوارهم في الكونسول (للتصحيح)
    console.log('🔎 مشاركو المجموعة:');
    groupMetadata.participants.forEach(p => {
        console.log(`- ${p.id} - الدور: ${p.admin || 'عضو'}`);
    });

    // البحث عن بيانات المستخدم الذي أرسل الأمر
    const userParticipant = groupMetadata.participants.find(p => p.id === m.sender);
    console.log('🔎 بيانات المستخدم الذي أرسل الأمر:', userParticipant);

    // التحقق إذا كان المستخدم admin أو مالك المجموعة
    const isUserAdmin = userParticipant?.admin === 'admin' || userParticipant?.admin === 'superadmin' || m.sender === groupMetadata.owner;

    if (!isUserAdmin) {
        return m.reply('❌ فقط المشرفين يمكنهم استخدام هذا الأمر.');
    }

    // تحديد المستخدم المراد طرده (عن طريق ذكر، أو رد، أو رقم)
    let user;
    if (m.mentionedJid && m.mentionedJid[0]) {
        user = m.mentionedJid[0];
    } else if (m.quoted) {
        user = m.quoted.sender;
    } else if (args[0]) {
        const number = args[0].replace(/[^0-9]/g, '');
        if (!number) return m.reply('⚠️ رقم غير صالح.');
        user = number + '@s.whatsapp.net';
    } else {
        return m.reply('🚫 يرجى ذكر المستخدم، الرد عليه أو كتابة رقم لطرده.');
    }

    const ownerGroup = groupMetadata.owner || m.chat.split`-`[0] + '@s.whatsapp.net';
    const ownerBot = global.owner[0][0] + '@s.whatsapp.net';

    if (user === conn.user.jid) return m.reply(`😂 لا يمكنني طرد نفسي.`);
    if (user === ownerGroup) return m.reply(`🙅‍♂️ لا يمكن طرد مالك المجموعة.`);
    if (user === ownerBot) return m.reply(`🙅‍♂️ لا يمكن طرد مالك البوت.`);

    try {
        await conn.groupParticipantsUpdate(m.chat, [user], 'remove');
        await m.reply(`✅ تم طرد المستخدم بنجاح.`);
    } catch (e) {
        await m.reply(`❌ لم أستطع طرد المستخدم. ربما لست مشرفًا أو لا أملك الصلاحيات اللازمة.`);
    }
};

handler.help = ['طرد'];
handler.tags = ['group'];
handler.command = ['طرد'];
handler.register = true;

export default handler;