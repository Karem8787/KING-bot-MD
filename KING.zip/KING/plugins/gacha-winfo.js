import { promises as fs } from 'fs';

const charactersFilePath = './database/characters.json';
const haremFilePath = './database/harem.json';

async function loadCharacters() {
    try {
        const data = await fs.readFile(charactersFilePath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        throw new Error('✎ لم نتمكن من جلب المعلومات هذه المرة.\n> *إذا كنت تعتقد أن هذا خطأ، بلّغ المشرفين باستخدام /report.*');
    }
}

async function loadHarem() {
    try {
        const data = await fs.readFile(haremFilePath, 'utf-8');
        return JSON.parse(data);
    } catch {
        return [];
    }
}

let handler = async (m, { conn, args }) => {
    if (args.length === 0) {
        await conn.sendMessage(m.chat, { 
            text: '✎ نحتاج إلى اسم للبحث عن المعلومات.\n> *مثال:* `#winfo Aika Sano`', 
            ...global.rcanal 
        }, { quoted: m });
        return;
    }

    const characterName = args.join(' ').toLowerCase().trim();

    try {
        const characters = await loadCharacters();
        const character = characters.find(c => c.name.toLowerCase() === characterName);

        if (!character) {
            await conn.sendMessage(m.chat, { 
                text: `✎ لم نعثر على معلومات بهذا الاسم.\n> *هل أنت متأكد أن "${characterName}" موجود؟*`, 
                ...global.rcanal 
            }, { quoted: m });
            return;
        }

        const harem = await loadHarem();
        const userEntry = harem.find(entry => entry.characterId === character.id);
        const statusMessage = userEntry
            ? `تمت المطالبة بها من قبل @${userEntry.userId.split('@')[0]}`
            : 'متاحة';

        const message = `╭───── ⌜📌⌟ ─────
│ *❀ معلومات الوايفو:*
├─────────────────
┃✎ *الاسم:* » *${character.name}*
┃✎ *النوع:* » *${character.gender}*
┃✎ *القيمة:* » *${character.value}*
┃✎ *الحالة:* » ${statusMessage}
┃✎ *المصدر:* » *${character.source}*
╰─────────────────`;

        await conn.sendMessage(m.chat, { 
            text: message, 
            mentions: userEntry ? [userEntry.userId] : [], 
            ...global.rcanal 
        }, { quoted: m });
    } catch (error) {
        await conn.sendMessage(m.chat, { 
            text: `✎ حدث خطأ أثناء جلب المعلومات.`, 
            ...global.rcanal 
        }, { quoted: m });
    }
};

handler.help = ['معلومات'];
handler.tags = ['gacha'];
handler.command = ['معلومات']; // ← أضفنا الأمر العربي
handler.group = false;
handler.register = true;

export default handler;