import fs from 'fs'
import path from 'path'

const handler = async (m, { conn }) => {
  const start = performance.now()

  // الحصول على رقم البوت الحالي (الجلسة)
  const botActual = conn.user?.jid?.split('@')[0].replace(/\D/g, '')
  const configPath = path.join('./JadiBots', botActual, 'config.json')

  let nombreBot = global.namebot || '✧ ʏᴜʀᴜ ʏᴜʀɪ ✧'

  if (fs.existsSync(configPath)) {
    try {
      const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'))
      if (config.name) nombreBot = config.name
    } catch (err) {
      console.log('⚠️ لم أتمكن من قراءة إعدادات البوت الفرعي:', err)
    }
  }

  // إرسال رسالة لقياس وقت الاستجابة الحقيقي
  const sentMsg = await conn.sendMessage(m.chat, { text: '🏓 جاري قياس الاستجابة...' }, { quoted: m })

  const end = performance.now()
  const realPing = Math.round(end - start)

  // إن كان هناك وقت استجابة WS، نعرضه أيضاً
  const wsPing = conn?.ws?.ping?.last || 0

  await conn.sendMessage(m.chat, { 
    text: `☁︎ *زمن الاستجابة:* ${realPing} مللي ثانية\n> ${nombreBot}` 
  }, { quoted: sentMsg })
}

handler.command = ['سرعه']
export default handler