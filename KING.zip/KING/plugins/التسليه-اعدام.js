let handler = async (m, { conn, participants }) => {

    if (!m.isGroup) throw '❗هذا الأمر يعمل فقط داخل المجموعات'

    if (participants.length < 2) throw '❗المجموعة تحتاج على الأقل شخصين لاستخدام هذا الأمر'

    let others = participants.filter(p => p.id !== m.sender)

    let randomUser = others[Math.floor(Math.random() * others.length)].id

    const executions = [

        '☠️💀 تم تأكيد إدانتك بالجريمة التي تقضي عليك بالإعدام عن جرم قتل متعمد ووحشي',

        '⚰️🔥 حكم عليك بالإعدام شنقًا بسبب خيانة وطنية',

        '🔪🩸 تم القبض عليك وأدينت بالإعدام لجرم قتل متعمد',

        '☠️💀 أُدينت بالإعدام شنقًا بعد محاكمة سريعة بسبب جريمة قتل',

        '⚰️🔥 حكم الإعدام الصادر بحقك جاء بعد تورطك في جريمة قتل مروعة',

    ]

    const randomExecution = executions[Math.floor(Math.random() * executions.length)]

    let message = `@${randomUser.split('@')[0]} , *${randomExecution}*`

    await conn.sendMessage(m.chat, { text: message, mentions: [randomUser] }, { quoted: m })

}

handler.help = ["اعدام"]

handler.tags = ['fun']

handler.command = /^(اعدام)$/i

export default handler