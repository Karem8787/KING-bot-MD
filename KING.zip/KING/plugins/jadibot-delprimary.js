let handler = async (m, { conn, text }) => {
  if (!text || !text.endsWith('@g.us')) {
    return m.reply('⚠️ يجب كتابة معرف المجموعة بشكل صحيح، مثال:\n.delprimary 120363xxxxx@g.us')
  }

  const groupId = text.trim()

  try {
    const participants = await conn.groupMetadata(groupId).then(res => res.participants)
    const userInGroup = participants.find(p => p.id === m.sender)

    if (!userInGroup) return m.reply('❌ أنت لست ضمن هذه المجموعة، لا يمكنك تعديلها.')

    if (!userInGroup.admin && userInGroup.role !== 'admin' && userInGroup.role !== 'superadmin') {
      return m.reply('❌ أنت لست مشرفاً في هذه المجموعة، لا يمكنك حذف البوت الرئيسي.')
    }

    if (!global.db.data.chats[groupId]) global.db.data.chats[groupId] = {}

    if (!global.db.data.chats[groupId].primaryBot) {
      return m.reply('⚠️ هذه المجموعة لا تحتوي على بوت رئيسي معين.')
    }

    delete global.db.data.chats[groupId].primaryBot

    m.reply(`✅ تم حذف البوت الرئيسي من المجموعة:\n*${groupId}*`)
  } catch (e) {
    console.error(e)
    m.reply('❌ لم أتمكن من الوصول إلى هذه المجموعة. تأكد أن البوت موجود ضمن المجموعة وأن المعرف صحيح.')
  }
}

handler.help = ['حذف_الرائيسي <ID_المجموعة>']
handler.tags = ['serbot']
handler.command = ['حذف_الرائيسي']

export default handler