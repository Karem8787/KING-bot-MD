let handler = async (m, { conn, participants }) => {

  let users = participants.map(u => u.id).filter(v => v !== m.sender)

  if (users.length < 2) throw 'المجموعة تحتاج على الأقل عضوين غيرك لتفعيل الأمر'

  let killer = users[Math.floor(Math.random() * users.length)]

  let victim = users[Math.floor(Math.random() * users.length)]

  while (killer === victim) {

    victim = users[Math.floor(Math.random() * users.length)]

  }

  let endings = [

    "تـم القبض على القاتل في مسرح الجريمة! 🔍🕵️",

    "العدالة أخذت مجراها وتم توقيف القاتل! ⚖️",

    "المجرم في قبضة الشرطة الآن! 🚔",

    "تم اقتياد القاتل إلى التحقيق حالًا! 👮‍♂️",

    "خيوط الجريمة قادتنا للقاتل وتم القبض عليه! 🔗",

    "القاتل ما زال هاربًا! البحث جارٍ... 🏃‍♂️💨",

    "القاتل فر من مسرح الجريمة ولا أثر له حتى الآن! 😱",

    "تم قتل القاتل أثناء المطاردة 🔫",

    "انتحر القاتل قبل أن تصل الشرطة! 💥",

    "أحد المبلغين ساعد الشرطة وتم القبض على القاتل! ☎️"

  ]

  let ending = endings[Math.floor(Math.random() * endings.length)]

  const text = `

🧬 تـم الـإعـلان عـن جـريـمـة قـتـل 🧬

⧉🔪 ╎الـقـاتـل : @${killer.split('@')[0]}

⧉⚰️ ╎الـمـقـتـول : @${victim.split('@')[0]}

${ending}

> الأمر للمزاح فقط

`.trim()

  conn.reply(m.chat, text, m, {

    mentions: [killer, victim]

  })

}

handler.help = ['قتل']

handler.tags = ['fun']

handler.command = /^قتل$/i

export default handler