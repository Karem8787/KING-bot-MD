const handler = async (msg, { conn }) => {
  try {
    const chats = Object.entries(conn.chats)
      .filter(([jid, chat]) => jid.endsWith('@g.us'))

    if (chats.length === 0) {
      await conn.sendMessage(msg.key.remoteJid, {
        text: '❌ البوت غير موجود في أي مجموعة.'
      }, { quoted: msg })
      return
    }

    let response = '*📃 قائمة الجروبات المرتبط بها البوت:*\n\n'

    let index = 1
    const groupList = []

    for (const [jid, chat] of chats) {
      try {
        const metadata = await conn.groupMetadata(jid)
        const invite = await conn.groupInviteCode(jid)
        const name = metadata.subject
        const link = `https://chat.whatsapp.com/${invite}`
        response += `*${index}.* ${name}\n🔗 ${link}\n\n`
        groupList.push({ jid, name })
        index++
      } catch (e) {
        // تجاهل الجروبات التي لا يمكن قراءة بياناتها
        continue
      }
    }

    // حفظ قائمة الجروبات مؤقتًا في المتغير العام
    global.groupListForFCommand = groupList

    await conn.sendMessage(msg.key.remoteJid, { text: response }, { quoted: msg })
  } catch (err) {
    console.error(err)
    await conn.sendMessage(msg.key.remoteJid, {
      text: '❌ حدث خطأ أثناء جلب الجروبات.'
    }, { quoted: msg })
  }
}

handler.command = /^ف$/i
export default handler