//--> صنع بواسطة Ado-rgb (github.com/Ado-rgb)
// •|• لا تزيل الحقوق..

import fetch from 'node-fetch'

let linkRegex = /chat\.whatsapp\.com\/[0-9A-Za-z]{20,24}/i
let linkRegex1 = /whatsapp\.com\/channel\/[0-9A-Za-z]{20,24}/i
const defaultImage = 'https://files.catbox.moe/ubftco.jpg'

// التحقق من أن المرسل أدمن أو صاحب البوت
async function هو_أدمن_أو_المالك(m, conn) {
  try {
    const بيانات_المجموعة = await conn.groupMetadata(m.chat)
    const العضو = بيانات_المجموعة.participants.find(p => p.id === m.sender)
    return العضو?.admin || m.fromMe
  } catch {
    return false
  }
}

const handler = async (m, { conn, command, args, isAdmin, isOwner }) => {
  if (!m.isGroup) return m.reply('🔒 هذا الأمر يعمل فقط في المجموعات.')

  if (!global.db.data.chats[m.chat]) global.db.data.chats[m.chat] = {}
  const الدردشة = global.db.data.chats[m.chat]
  const النوع = (args[0] || '').toLowerCase()
  const تفعيل = command === 'تشغيل'

  if (!['منع_روابط', 'ترحيب', 'طرد_الاجانب', 'وضع_الادمن'].includes(النوع)) {
    return m.reply(`✳️ الاستخدام:\n*.تشغيل رابط* / *.ايقاف رابط*\n*.تشغيل ترحيب* / *.ايقاف ترحيب*\n*.تشغيل طردالعرب* / *.ايقاف طردالعرب*\n*.تشغيل وضعالادمن* / *.ايقاف وضعالادمن*`)
  }

  if (!(isAdmin || isOwner)) return m.reply('❌ فقط المشرفين يمكنهم استخدام هذا الأمر.')

  if (النوع === 'منع_روابط') {
    الدردشة.antilink = تفعيل
    return m.reply(`✅ الحماية من الروابط ${تفعيل ? 'تم تفعيلها' : 'تم إيقافها'}.`)
  }

  if (النوع === 'ترحيب') {
    الدردشة.welcome = تفعيل
    return m.reply(`✅ الترحيب ${تفعيل ? 'تم تفعيله' : 'تم إيقافه'}.`)
  }

  if (النوع === 'طرد_الاجانب') {
    الدردشة.antiarabe = تفعيل
    return m.reply(`✅ طرد الأرقام العربية ${تفعيل ? 'تم تفعيله' : 'تم إيقافه'}.`)
  }

  if (النوع === 'وضع_الادمن') {
    الدردشة.modoadmin = تفعيل
    return m.reply(`✅ وضع المشرفين فقط ${تفعيل ? 'تم تفعيله' : 'تم إيقافه'}.`)
  }
}

handler.command = ['تشغيل', 'ايقاف']
handler.group = true
handler.register = true
handler.tags = ['المجموعة']
handler.help = ['تشغيل ترحيب', 'ايقاف ترحيب', 'تشغيل رابط', 'ايقاف رابط', 'تشغيل وضعالادمن', 'ايقاف وضعالادمن']

// دالة تفحص الرسائل قبل تنفيذ الأوامر
handler.before = async (m, { conn }) => {
  if (!m.isGroup) return
  if (!global.db.data.chats[m.chat]) global.db.data.chats[m.chat] = {}
  const الدردشة = global.db.data.chats[m.chat]

  // وضع الادمن فقط
  if (الدردشة.modoadmin) {
    const بيانات_المجموعة = await conn.groupMetadata(m.chat)
    const هو_أدمن = بيانات_المجموعة.participants.find(p => p.id === m.sender)?.admin
    if (!هو_أدمن && !m.fromMe) return // تجاهل غير الأدمن
  }

  // طرد الأرقام العربية
  if (الدردشة.antiarabe && m.messageStubType === 27) {
    const العضو_الجديد = m.messageStubParameters?.[0]
    if (!العضو_الجديد) return

    const الرقم = العضو_الجديد.split('@')[0].replace(/\D/g, '')
    const رموز_عربية = ['212', '20', '971', '965', '966', '974', '973', '962']
    const هو_عربي = رموز_عربية.some(prefix => الرقم.startsWith(prefix))

    if (هو_عربي) {
      await conn.sendMessage(m.chat, { text: `🚷 العضو ${العضو_الجديد} سيتم طرده، لا نرغب في أرقام عربية هنا.\n[ خاصية طرد العرب مفعلة ✅ ]` })
      await conn.groupParticipantsUpdate(m.chat, [العضو_الجديد], 'remove')
      return true
    }
  }

  // الحماية من الروابط
  if (الدردشة.antilink) {
    const بيانات_المجموعة = await conn.groupMetadata(m.chat)
    const هو_أدمن = بيانات_المجموعة.participants.find(p => p.id === m.sender)?.admin
    const النص = m?.text || ''

    if (!هو_أدمن && (linkRegex.test(نص) || linkRegex1.test(نص))) {
      const التاغ = `@${m.sender.split('@')[0]}`
      const المرسل = m.key.participant
      const معرف_الرسالة = m.key.id

      try {
        const رابط_المجموعة = `https://chat.whatsapp.com/${await conn.groupInviteCode(m.chat)}`
        if (نص.includes(رابط_المجموعة)) return
      } catch {}

      try {
        await conn.sendMessage(m.chat, {
          text: `🚫 عذرًا ${التاغ}, الروابط غير مسموحة هنا.`,
          mentions: [m.sender]
        }, { quoted: m })

        await conn.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: معرف_الرسالة,
            participant: المرسل
          }
        })

        await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
      } catch {
        await conn.sendMessage(m.chat, {
          text: `⚠️ لم أتمكن من حذف الرسالة أو طرد ${التاغ}. ربما ليس لدي صلاحيات.`,
          mentions: [m.sender]
        }, { quoted: m })
      }
      return true
    }
  }

  // الترحيب والوداع
  if (الدردشة.welcome && [27, 28, 32].includes(m.messageStubType)) {
    const بيانات_المجموعة = await conn.groupMetadata(m.chat)
    const عدد_الأعضاء = بيانات_المجموعة.participants.length
    const معرف_العضو = m.messageStubParameters?.[0] || m.sender
    const التاغ = `@${معرف_العضو.split('@')[0]}`
    let صورة_الملف

    try {
      صورة_الملف = await conn.profilePictureUrl(معرف_العضو, 'image')
    } catch {
      صورة_الملف = defaultImage
    }

    if (m.messageStubType === 27) {
      const نص_الترحيب = '↷✦; مرحبًا ❞'
      const ترحيب = `
✿ *أهلًا بك* في *${بيانات_المجموعة.subject}*   
✰ ${التاغ}، نورتنا 😊 
✦ عددنا الآن: *${عدد_الأعضاء}*
`.trim()

      await conn.sendMessage(m.chat, {
        image: { url: صورة_الملف },
        caption: `${نص_الترحيب}\n\n${ترحيب}`,
        contextInfo: { mentionedJid: [معرف_العضو] }
      })
    }

    if (m.messageStubType === 28 || m.messageStubType === 32) {
      const نص_الوداع = '↷✦; إلى اللقاء ❞'
      const وداع = `
✿ *وداعًا* من *${بيانات_المجموعة.subject}*   
✰ ${التاغ}، نتمنى رؤيتك مجددًا 👋  
✦ عددنا الآن: *${عدد_الأعضاء}*
`.trim()

      await conn.sendMessage(m.chat, {
        image: { url: صورة_الملف },
        caption: `${نص_الوداع}\n\n${وداع}`,
        contextInfo: { mentionedJid: [معرف_العضو] }
      })
    }
  }
}

export default handler