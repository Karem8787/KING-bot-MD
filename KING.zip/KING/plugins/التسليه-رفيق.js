let handler = async (m, { conn, participants }) => {

  // استخراج الأعضاء واستبعاد البوت والمُرسل

  let users = participants.map(u => u.id).filter(v => v !== m.sender && v !== conn.user.id)

  if (users.length === 0) throw 'لا يوجد أعضاء كفاية في المجموعة لاختيار رفيق!'

  // اختيار شخص عشوائي كتوأم الروح

  let soulmate = users[Math.floor(Math.random() * users.length)]

  const message = `*توأمك الـروحـي هو ☜* @${soulmate.replace(/@.+/, '')}`

  await conn.sendMessage(m.chat, { 

    text: `@${m.sender.replace(/@.+/, '')} ${message}`, 

    mentions: [m.sender, soulmate] 

  }, { quoted: m })

}

handler.help = ['رفيق']

handler.tags = ['fun']

handler.command = /^رفيق$/i

export default handler