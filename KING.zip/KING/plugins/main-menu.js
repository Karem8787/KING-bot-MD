import fs from 'fs'
import { join } from 'path'
import { xpRange } from '../lib/levelling.js'

const tags = {
  serbot: '🌐 البوتات الفرعية',
  eco: '💸 الاقتصاد',
  downloader: '⬇️ التنزيلات',
  tools: '🛠️ الأدوات',
  owner: '👑 المالك',
  info: 'ℹ️ المعلومات',
  game: '🎮 الألعاب',
  gacha: '🎲 انمي قاشا',
  group: '👥 المجموعات',
  search: '🔎 البحث',
  sticker: '📌 الملصقات',
  ia: '🤖 الذكاء الاصطناعي',
  channel: '📺 القنوات',
  fun: '😂 الترفيه',
}

const defaultMenu = {
  before: `
 *⟣━┏─╆╾┉⤸⛓️⤹┉╼╅─┓━⟢*
> 🌟 *مرحباً، أنا %KING*\n> _%tipo_

> 👋 أهلاً *%name*، %greeting

> 📅 التاريخ: *%date*
> ⏳ مدة التشغيل: *%uptime*
%readmore`.trimStart(),

  header: '\n*%category* 💚',
  body: '> 🫟 %cmd %islimit %isPremium',
  footer: '',
  after: '\n*⟣━┏─╆╾┉⤸⛓️⤹┉╼╅─┓━⟢*',
}

const handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    const { exp, limit, level } = global.db.data.users[m.sender]
    const { min, xp, max } = xpRange(level, global.multiplier)
    const name = await conn.getName(m.sender)

    const d = new Date(Date.now() + 3600000)
    const locale = 'ar'
    const date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })

    const help = Object.values(global.plugins)
      .filter(p => !p.disabled)
      .map(plugin => ({
        help: Array.isArray(plugin.help) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: 'customPrefix' in plugin,
        limit: plugin.limit,
        premium: plugin.premium,
      }))

    let nombreBot = global.namebot || 'البوت'
    let bannerFinal = './storage/img/menu.jpg'

    const botActual = conn.user?.jid?.split('@')[0].replace(/\D/g, '')
    const configPath = join('./JadiBots', botActual, 'config.json')

    if (fs.existsSync(configPath)) {
      try {
        const config = JSON.parse(fs.readFileSync(configPath))
        if (config.name) nombreBot = config.name
        if (config.banner) bannerFinal = config.banner
      } catch (err) {
        console.log('⚠️ لم يتم قراءة إعدادات البوت الفرعي:', err)
      }
    }

    const tipo = conn.user.jid === global.conn.user.jid
      ? 'بوت رئيسي 🪴'
      : 'بوت فرعي 🍃'

    const menuConfig = conn.menu || defaultMenu

    const _text = [
      menuConfig.before,
      ...Object.keys(tags).map(tag => {
        return [
          menuConfig.header.replace(/%category/g, tags[tag]),
          help.filter(menu => menu.tags?.includes(tag)).map(menu =>
            menu.help.map(helpText =>
              menuConfig.body
                .replace(/%cmd/g, menu.prefix ? helpText : `${_p}${helpText}`)
                .replace(/%islimit/g, menu.limit ? '◜⭐◞' : '')
                .replace(/%isPremium/g, menu.premium ? '◜🪪◞' : '')
                .trim()
            ).join('\n')
          ).join('\n'),
          menuConfig.footer,
        ].join('\n')
      }),
      menuConfig.after
    ].join('\n')

    const replace = {
      '%': '%',
      p: _p,
      botname: nombreBot,
      taguser: '@' + m.sender.split('@')[0],
      exp: exp - min,
      maxexp: xp,
      totalexp: exp,
      xp4levelup: max - exp,
      level,
      limit,
      name,
      date,
      uptime: clockString(process.uptime() * 1000),
      tipo,
      readmore: readMore,
      greeting,
    }

    const text = _text.replace(
      new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join('|')})`, 'g'),
      (_, name) => String(replace[name])
    )

    const isURL = typeof bannerFinal === 'string' && /^https?:\/\//i.test(bannerFinal)
    const imageContent = isURL
      ? { image: { url: bannerFinal } }
      : { image: fs.readFileSync(bannerFinal) }

    await conn.sendMessage(m.chat, {
      ...imageContent,
      caption: text.trim(),
      mentionedJid: conn.parseMention(text)
    }, { quoted: m })

  } catch (e) {
    console.error('❌ خطأ في القائمة:', e)
    conn.reply(m.chat, '❎ عذرًا، هناك خطأ في القائمة.', m)
  }
}

handler.command = ['اوامر'] // أضفنا أمر عربي واحد فقط
handler.register = true
export default handler

// أدوات مساعدة
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}

const ase = new Date()
let hour = ase.getHours()

const greetingMap = {
  0: 'مساء هادئ 🌙', 1: 'مساء طيب 💤', 2: 'مساء ساكن 🦉',
  3: 'صباح جميل ✨', 4: 'صباح مشرق 💫', 5: 'صباح باكر 🌅',
  6: 'صباح باكر 🌄', 7: 'صباح جميل 🌅', 8: 'صباح نشيط 💫',
  9: 'صباح مشرق ✨', 10: 'نهار جميل 🌞', 11: 'نهار غائم 🌨',
  12: 'نهار بارد ❄', 13: 'نهار معتدل 🌤', 14: 'مساء هادئ 🌇',
  15: 'مساء جميل 🥀', 16: 'مساء ورد 🌹', 17: 'مساء مشمس 🌆',
  18: 'مساء دافئ 🌙', 19: 'ليلة سعيدة 🌃', 20: 'ليلة هادئة 🌌',
  21: 'ليلة رائعة 🌃', 22: 'ليلة سعيدة 🌙', 23: 'ليلة ساكنة 🌃',
}
var greeting = 'أتمنى لك ' + (greetingMap[hour] || 'يوماً سعيداً')