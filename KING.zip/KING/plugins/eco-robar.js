const ro = 30;

const handler = async (m, { conn, usedPrefix, command }) => {
  const user = global.db.data.users[m.sender];
  const time = user.lastrob2 + 7200000;

  if (new Date - user.lastrob2 < 7200000) {
    return conn.reply(m.chat, `
❀ *معلومات السرقة*

➪ *اللاعب ›* @${m.sender.split('@')[0]}

> ✧ *الحالة ›* تحت التبريد
> ✧ *الوقت المتبقي ›* ${msToTime(time - new Date())}
`, m, { mentions: [m.sender], ...global.rcanal });
  }

  let who;
  if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false;
  else who = m.chat;

  if (!who) {
    return conn.reply(m.chat, `
❀ *معلومات السرقة*

➪ *اللاعب ›* @${m.sender.split('@')[0]}

> ✧ *خطأ ›* لازم تعمل منشن لحد تسرقه
`, m, { mentions: [m.sender], ...global.rcanal });
  }

  if (!(who in global.db.data.users)) {
    return conn.reply(m.chat, `
❀ *معلومات السرقة*

➪ *اللاعب ›* @${m.sender.split('@')[0]}

> ✧ *خطأ ›* الشخص ده مش موجود في قاعدة البيانات
`, m, { mentions: [m.sender], ...global.rcanal });
  }

  const target = global.db.data.users[who];
  const rob = Math.floor(Math.random() * ro);

  if (target.coin < rob) {
    return conn.reply(m.chat, `
❀ *معلومات السرقة*

➪ *اللاعب ›* @${m.sender.split('@')[0]}

> ✧ *الحالة ›* فشلت
> ✧ *السبب ›* @${who.split`@`[0]} معهوش فلوس كفاية
`, m, { mentions: [m.sender, who], ...global.rcanal });
  }

  user.coin += rob;
  target.coin -= rob;
  user.lastrob2 = new Date * 1;

  conn.reply(m.chat, `
❀ *معلومات السرقة*

➪ *اللص ›* @${m.sender.split('@')[0]}
➪ *الضحية ›* @${who.split('@')[0]}

> ✧ *الغنيمة ›* ${rob} ${moneda}
> ✧ *الحالة ›* سرقة ناجحة
`, m, { mentions: [m.sender, who], ...global.rcanal });
};

handler.help = ['اسرق'];
handler.tags = ['eco'];
handler.command = ['اسرق'];
handler.group = false;
handler.register = true;

export default handler;

function msToTime(duration) {
  let seconds = Math.floor((duration / 1000) % 60);
  let minutes = Math.floor((duration / (1000 * 60)) % 60);
  let hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

  hours = hours < 10 ? '0' + hours : hours;
  minutes = minutes < 10 ? '0' + minutes : minutes;
  seconds = seconds < 10 ? '0' + seconds : seconds;

  return `${hours}h ${minutes}m ${seconds}s`;
}