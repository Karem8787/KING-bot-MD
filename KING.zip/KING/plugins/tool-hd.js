import fetch from 'node-fetch'
import FormData from 'form-data'

async function uploadImage(buffer) {
  const form = new FormData()
  form.append('fileToUpload', buffer, 'image.jpg')
  form.append('reqtype', 'fileupload')

  const res = await fetch('https://catbox.moe/user/api.php', { method: 'POST', body: form })
  if (!res.ok) throw new Error('حدث خطأ أثناء رفع الصورة')
  return await res.text()
}

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    await m.react('🕓')

    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || ''
    if (!mime) {
      return conn.sendMessage(m.chat, {
        text: `❀ من فضلك أرسل صورة أو رد على صورة باستخدام *${usedPrefix + command}*`,
        ...global.rcanal
      }, { quoted: m })
    }
    if (!/image\/(jpe?g|png|webp)/.test(mime)) {
      return conn.sendMessage(m.chat, {
        text: `✧ صيغة الملف (${mime}) غير مدعومة، الرجاء استخدام JPG، PNG أو WEBP.`,
        ...global.rcanal
      }, { quoted: m })
    }

    await conn.sendMessage(m.chat, {
      text: `✧ جارٍ تحسين صورتك، انتظر من فضلك...`,
      ...global.rcanal
    }, { quoted: m })

    let img = await q.download?.()
    if (!img) throw new Error('لم أتمكن من تحميل الصورة.')

    let uploadedUrl = await uploadImage(img)

    const apiUrl = `https://fastapi.alifproject.cloud/api/ai/upscalev2?url=${encodeURIComponent(uploadedUrl)}`
    const res = await fetch(apiUrl)
    if (!res.ok) throw new Error(`خطأ في API: ${res.statusText}`)
    const data = await res.json()

    if (data.status !== 'success' || !data.data?.result_url) throw new Error('لم أتمكن من تحسين الصورة.')

    const improvedRes = await fetch(data.data.result_url)
    const buffer = await improvedRes.buffer()

    await conn.sendMessage(m.chat, {
      image: buffer,
      caption: '✅ *تم تحسين الصورة بنجاح*',
      ...global.rcanal
    }, { quoted: m })

    await m.react('✅')
  } catch (e) {
    console.error(e)
    await m.react('✖️')
    await conn.sendMessage(m.chat, {
      text: '❌ *حدث خطأ أثناء تحسين الصورة، حاول لاحقاً.*',
      ...global.rcanal
    }, { quoted: m })
  }
}

handler.help = ['جوده']
handler.tags = ['tools']
handler.command = ['جوده'] // أمر عربي واحد فقط

export default handler