let handler = async (m, { conn, participants }) => {

  let users = participants.map(u => u.id).filter(v => v !== m.sender)

  if (users.length < 2) throw 'المجموعة تحتاج على الأقل عضوين غيرك لتفعيل الأمر'

  // اختار منشنين عشوائيين

  let user1 = users[Math.floor(Math.random() * users.length)]

  let user2 = users[Math.floor(Math.random() * users.length)]

  while (user2 === user1) {

    user2 = users[Math.floor(Math.random() * users.length)]

  }

  const text = `

🔥🔥 يا جماعة، دقت ساعة الانتقام!

@${user1.split('@')[0]} , طلقها بالثلاثة لو عندك دم 😂

@${user2.split('@')[0]} , متقلقيش هاجوزك سيد سيدو! 😉

خلصت الحلقة، اشربوا عصير واضحكوا! 🍹😆

`.trim()

  const image = 'https://files.catbox.moe/hey1t8.jpg'

  await conn.sendFile(m.chat, image, 'طلاق.jpg', text, m, false, {

    mentions: [user1, user2]

  })

}

handler.help = ['طلاق']

handler.tags = ['fun']

handler.command = /^طلاق$/i

export default handler