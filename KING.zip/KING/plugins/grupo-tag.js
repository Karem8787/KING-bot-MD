const handler = async (msg, { conn, isOwner }) => {
  try {
    const chatId = msg.key.remoteJid
    const sender = (msg.key.participant || msg.key.remoteJid).replace(/[^0-9]/g, '')
    const isGroup = chatId.endsWith('@g.us')
    const isBotMessage = msg.key.fromMe

    await conn.sendMessage(chatId, { react: { text: '🔊', key: msg.key } })

    if (!isGroup) {
      await conn.sendMessage(chatId, {
        text: '⚠️ *هذا الأمر يمكن استخدامه فقط في المجموعات.*'
      }, { quoted: msg })
      return
    }

    const metadata = await conn.groupMetadata(chatId)
    const participant = metadata.participants.find(p => p.id.includes(sender))
    const isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin'

    if (!isAdmin && !isOwner && !isBotMessage) {
      await conn.sendMessage(chatId, {
        text: '❌ *هذا الأمر يمكن استخدامه فقط من قبل مشرف أو مالك البوت.*'
      }, { quoted: msg })
      return
    }

    const participants = metadata.participants
    const mentionList = participants.map(p => `➪ @${p.id.split('@')[0]}`).join('\n')
    const messageText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || ''
    const args = messageText.trim().split(' ').slice(1)
    const extraMsg = args.join(' ')

    let finalMsg = '*📢 تنبيه عام 📢* \n\n'
    if (extraMsg.trim().length > 0) {
      finalMsg += `❑ *الرسالة:* ${extraMsg}\n\n`
    }
    finalMsg += mentionList

    const mentionIds = participants.map(p => p.id)

    await conn.sendMessage(chatId, {
      text: finalMsg,
      mentions: mentionIds
    }, { quoted: msg })

  } catch (error) {
    console.error('❌ خطأ في تنفيذ أمر المنشن العام:', error)
    await conn.sendMessage(msg.key.remoteJid, {
      text: '❌ حدث خطأ أثناء تنفيذ أمر المنشن العام.'
    }, { quoted: msg })
  }
}

handler.tags = ['group']
handler.help = ['منشن']
handler.command = ['منشن']
handler.group = true

export default handler