// codigo creado por 
// github.com/Ado-rgb
import fs from 'fs'
import { downloadContentFromMessage } from '@whiskeysockets/baileys'

const handler = async (msg, { conn, args }) => {
  const chatId = msg.key.remoteJid

  if (
    !msg.message?.extendedTextMessage ||
    !msg.message.extendedTextMessage.contextInfo?.quotedMessage
  ) {
    return conn.sendMessage(
      chatId,
      {
        text: '📛 *خطأ:* يجب الرد على ملف وسائط (صورة، فيديو، صوت، ملصق أو مستند) مع كلمة مفتاحية لحفظه.'
      },
      { quoted: msg }
    )
  }

  const saveKey = args.join(' ').trim().toLowerCase()

  if (!/[a-zA-Z0-9]/.test(saveKey)) {
    return conn.sendMessage(
      chatId,
      {
        text: '⚠️ *تحذير:* يجب أن تحتوي الكلمة المفتاحية على حرف أو رقم على الأقل. الرموز أو الإيموجي فقط غير مسموح بها.'
      },
      { quoted: msg }
    )
  }

  // Verificar o crear el archivo guar.json
  if (!fs.existsSync('./guar.json')) {
    fs.writeFileSync('./guar.json', JSON.stringify({}, null, 2))
  }

  let guarData = JSON.parse(fs.readFileSync('./guar.json', 'utf-8'))

  if (guarData[saveKey]) {
    return conn.sendMessage(
      chatId,
      {
        text: `🚫 *تنبيه:* يوجد ملف محفوظ مسبقًا تحت الكلمة المفتاحية *"${saveKey}"*. الرجاء استخدام كلمة مختلفة.`
      },
      { quoted: msg }
    )
  }

  const quotedMsg = msg.message.extendedTextMessage.contextInfo.quotedMessage
  let mediaType, mediaMessage, fileExtension

  if (quotedMsg.imageMessage) {
    mediaType = 'image'
    mediaMessage = quotedMsg.imageMessage
    fileExtension = 'jpg'
  } else if (quotedMsg.videoMessage) {
    mediaType = 'video'
    mediaMessage = quotedMsg.videoMessage
    fileExtension = 'mp4'
  } else if (quotedMsg.audioMessage) {
    mediaType = 'audio'
    mediaMessage = quotedMsg.audioMessage
    fileExtension = 'mp3'
  } else if (quotedMsg.stickerMessage) {
    mediaType = 'sticker'
    mediaMessage = quotedMsg.stickerMessage
    fileExtension = 'webp'
  } else if (quotedMsg.documentMessage) {
    mediaType = 'document'
    mediaMessage = quotedMsg.documentMessage
    fileExtension = mediaMessage.mimetype.split('/')[1] || 'bin'
  } else {
    return conn.sendMessage(
      chatId,
      {
        text: '📎 *خطأ:* يسمح فقط بحفظ ملفات من نوع صورة، فيديو، صوت، ملصق أو مستند.'
      },
      { quoted: msg }
    )
  }

  const mediaStream = await downloadContentFromMessage(mediaMessage, mediaType)
  let mediaBuffer = Buffer.alloc(0)
  for await (const chunk of mediaStream) {
    mediaBuffer = Buffer.concat([mediaBuffer, chunk])
  }

  guarData[saveKey] = {
    buffer: mediaBuffer.toString('base64'),
    mimetype: mediaMessage.mimetype,
    extension: fileExtension,
    savedBy: msg.key.participant || msg.key.remoteJid
  }

  fs.writeFileSync('./guar.json', JSON.stringify(guarData, null, 2))

  return conn.sendMessage(
    chatId,
    {
      text: `✅ *تم الحفظ بنجاح:* تم تخزين الملف تحت الكلمة المفتاحية: *"${saveKey}"*.`
    },
    { quoted: msg }
  )
}

handler.command = handler.help = ['حفظ']  // إضافة أمر عربي 'حفظ'
handler.group = true
handler.tags = ['tools']

export default handler