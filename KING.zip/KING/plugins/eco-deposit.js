import db from '../lib/database.js'

let handler = async (m, { args }) => {
  let user = global.db.data.users[m.sender]

  if (!args[0]) return m.reply(`✧ اكتب الكمية اللي عايز تودعها من *${moneda}*.`)

  if (args[0] === 'all') {
    let count = parseInt(user.coin)
    if (!count || count < 1) return m.reply(`❀ معندكش حاجة تودعها.`)
    user.coin -= count
    user.bank += count
    await m.reply(`✿ أودعت *${count} ${moneda}* في البنك. كده محدش يقدر يسرقهم منك.`)
    return
  }

  if (isNaN(args[0])) return m.reply(`✦ اكتب رقم صحيح.\nمثال: *#d 5000*`)

  let count = parseInt(args[0])
  if (!user.coin || user.coin < 1) return m.reply(`✧ محفظتك فاضية.`)
  if (user.coin < count) return m.reply(`❀ معاك بس *${user.coin} ${moneda}*.`)

  user.coin -= count
  user.bank += count

  await m.reply(`✿ أودعت *${count} ${moneda}* في البنك.`)
}

handler.help = ['ايداع']
handler.tags = ['eco']
handler.command = ['ايداع']
handler.group = false
handler.register = true

export default handler