# ⚜️ KING-SOLO ⚜️
![KIND](https://files.catbox.moe/7qa6p3.jpg)

بوت واتساب بسيط صمم بحب.. 

---

### تصميم احترافي »
- خفيف الوزن وسهل الاستخدام - يعمل دون أي ضجة - مصنوع بتفانٍ ولمسة شخصية
___

## 🔥 كيف تشغلو ترمكس

> **اتبع الخطوات التالية بالترتيب:**

```bash
termux-setup-storage
```

```bash
apt update && apt upgrade && pkg install -y git nodejs ffmpeg imagemagick
```

```bash
مسار البوت
```

```bash
cd /sdcard/KING
```

```bash
npm install
ده لو مجلد node_modules
مش موجود تعملو
```

```bash
npm start
```

---

## 👤 المطور قناة

- 🍁 تلجرام: (https://t.me/HXAlR)


---

## 📜 رخصة

## كبنج مش محتاج رخص فاك ل اي حد مش عاجبو